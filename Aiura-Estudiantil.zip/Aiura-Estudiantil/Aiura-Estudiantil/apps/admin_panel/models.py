from datetime import date

from django.contrib.auth.models import User
from django.db import models


class Profesor(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    materia = models.CharField(max_length=100)
    cursos = models.ManyToManyField('Curso', related_name='profesores')

    def __str__(self):
        return self.user.get_full_name()

class Curso(models.Model):
    curso = models.CharField(max_length=50)  # Ejemplo: "Cuarto C"

    def __str__(self):
        return self.curso
    
class Alumno(models.Model):
    nombre = models.CharField(max_length=100)
    apellido = models.CharField(max_length=100)
    curso = models.ForeignKey('Curso', on_delete=models.CASCADE, related_name='alumno')

    def __str__(self):
        return self.get_full_name()

    def get_full_name(self):
        return f'{self.nombre} {self.apellido}'.strip()

class Asistencia(models.Model):
    alumno = models.ForeignKey('Alumno', on_delete=models.CASCADE, related_name='asistencias')
    fecha = models.DateField()
    asistio = models.BooleanField(default=False)  # True para asistencia, False para falta

    def __str__(self):
        return f"Asistencia de {self.alumno} el {self.fecha} - {'Presente' if self.asistio else 'Ausente'}"

class Nota(models.Model):
    alumno = models.ForeignKey('Alumno', on_delete=models.CASCADE, related_name='notas')
    curso = models.ForeignKey('Curso', on_delete=models.CASCADE, related_name='notas')
    enrollment_date = models.DateField(default=date.today)
    nota_1 = models.IntegerField(null=True, blank=True)
    nota_2 = models.IntegerField(null=True, blank=True)
    nota_3 = models.IntegerField(null=True, blank=True)
    nota_4 = models.IntegerField(null=True, blank=True)
    nota_5 = models.IntegerField(null=True, blank=True)
    final_grade = models.IntegerField(null=True, blank=True)

    @property
    def promedio(self):
        notes = [self.nota_1, self.nota_2, self.nota_3, self.nota_4, self.nota_5]
        valid_notes = [note for note in notes if note is not None]

        if valid_notes:
            return round(sum(valid_notes) / len(valid_notes), 0)
        return None

    def __str__(self):
        return f"Notas de {self.alumno}"
