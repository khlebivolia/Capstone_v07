import os
import errno  # Agregamos esta importación
from django.conf import settings
from django.http import FileResponse, JsonResponse, Http404
from django.core.files.storage import FileSystemStorage
from django.views.decorators.csrf import ensure_csrf_cookie
from pathlib import Path
from django.contrib import messages
from django.contrib.auth import logout
from django.contrib.auth.decorators import user_passes_test
from django.db.models import Avg, Count, Q
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect
from django.shortcuts import render
from django.utils import timezone
from .forms import CourseForm, StudentForm, TeacherForm
from .models import Alumno, Curso, Nota, Profesor

def superuser_required(view_func):
    return user_passes_test(lambda user: user.is_superuser)(view_func)

def get_search_filter(search, str_fields, int_fields):
    q = Q()
    if search:
        for term in search.split():
            term_query = Q()
            for field in str_fields:
                term_query |= Q(**{f"{field}__icontains": term})
            if term.isdigit():
                for field in int_fields:
                    term_query |= Q(**{field: int(term)})
            q &= term_query
    return q

@superuser_required
def admin_dashboard(request):
    context = {
        'total_teachers': Profesor.objects.count(),
        'total_courses': Curso.objects.count(),
        'total_students': Alumno.objects.count(),
        'total_enrollments': Nota.objects.count(),
        'today': timezone.now().date(),
    }
    return render(request, 'admin/dashboard.html', context)

# Vistas para editar profesores
@superuser_required
def manage_teachers(request):
    if request.method == 'POST':
        form = TeacherForm(request.POST)
        if form.is_valid():
            teacher = form.save()
            messages.success(request, f'Profesor {teacher.user.first_name} agregado exitosamente.')
            return redirect('admin_panel:manage_teachers')
    else:
        form = TeacherForm()

    teachers = Profesor.objects.filter(get_search_filter(
        request.GET.get('search'),
        str_fields=['materia', 'user__username', 'user__first_name',
                    'user__last_name', 'user__email'],
        int_fields=['id']
    )).annotate(
        course_count=Count('cursos', distinct=True),
        student_count=Count('cursos__alumno', distinct=True)
    ).order_by('id')

    context = {
        'teachers': teachers,
        'form': form,
    }
    return render(request, 'admin/manage_teachers.html', context)

@superuser_required
def edit_teacher(request, teacher_id):
    teacher = get_object_or_404(Profesor, id=teacher_id)
    if request.method == 'POST':
        form = TeacherForm(request.POST, instance=teacher)
        if form.is_valid():
            form.save()
            return JsonResponse({'success': True})
        else:
            return JsonResponse({'success': False, 'errors': form.errors}, status=400)
    else:
        data = {
            'first_name': teacher.user.first_name,
            'last_name': teacher.user.last_name,
            'email': teacher.user.email,
            'materia': teacher.materia,
            'username': teacher.user.username,
            'cursos': list(teacher.cursos.values_list('id', flat=True)),
        }
        return JsonResponse(data)

@superuser_required
def delete_teacher(request, teacher_id):
    if request.method == 'POST':
        teacher = get_object_or_404(Profesor, id=teacher_id)
        teacher.user.delete()
        teacher.delete()
        return JsonResponse({'success': True})
    return JsonResponse({'error': 'Invalid request'}, status=400)

# Vistas para editar cursos
@superuser_required
def manage_courses(request):
    if request.method == 'POST':
        form = CourseForm(request.POST)
        if form.is_valid():
            course = form.save()
            messages.success(request, f'Curso "{course.curso}" agregado exitosamente.')
            return redirect('admin_panel:manage_courses')
    else:
        form = CourseForm()

    courses = Curso.objects.filter(get_search_filter(
        request.GET.get('search'),
        str_fields=['curso'],
        int_fields=['id']
    )).prefetch_related('profesores', 'alumno').annotate(
        student_count=Count('alumno', distinct=True),
        teacher_count=Count('profesores', distinct=True),
    ).order_by('id')
    
    context = {
        'courses': courses,
        'form': form,
    }
    return render(request, 'admin/manage_courses.html', context)

@superuser_required
def edit_course(request, course_id):
    course = get_object_or_404(Curso, id=course_id)
    if request.method == 'POST':
        form = CourseForm(request.POST, instance=course)
        if form.is_valid():
            form.save()
            return JsonResponse({'success': True})
        else:
            return JsonResponse({'success': False, 'errors': form.errors}, status=400)
    else:
        data = {
            'curso': course.curso,
            'profesores': list(course.profesores.values_list('id', flat=True)),
        }
        return JsonResponse(data)

@superuser_required
def delete_course(request, course_id):
    if request.method == 'POST':
        course = get_object_or_404(Curso, id=course_id)
        course.delete()
        return JsonResponse({'success': True})
    return JsonResponse({'error': 'Invalid request'}, status=400)

# Vistas para editar estudiantes
@superuser_required
def manage_students(request):
    if request.method == 'POST':
        form = StudentForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Alumno agregado exitosamente.')
            return redirect('admin_panel:manage_students')
    else:
        form = StudentForm()

    student = Alumno.objects.filter(get_search_filter(
        request.GET.get('search'),
        str_fields=['nombre', 'apellido', 'curso__curso'],
        int_fields=['id']
    )).annotate(
        avg_grade=Avg('notas__final_grade')
    ).order_by('id')

    context = {
        'students': student,
        'form': form,
    }
    return render(request, 'admin/manage_students.html', context)

@superuser_required
def edit_student(request, student_id):
    student = get_object_or_404(Alumno, id=student_id)
    if request.method == 'POST':
        form = StudentForm(request.POST, instance=student)
        if form.is_valid():
            form.save()
            return JsonResponse({'success': True})
        else:
            return JsonResponse({'success': False, 'errors': form.errors}, status=400)
    else:
        data = {
            'nombre': student.nombre,
            'apellido': student.apellido,
            'curso': student.curso_id,
        }
        return JsonResponse(data)

@superuser_required
def delete_student(request, student_id):
    if request.method == 'POST':
        student = get_object_or_404(Alumno, id=student_id)
        student.delete()
        return JsonResponse({'success': True})
    return JsonResponse({'error': 'Invalid request'}, status=400)


# Definir la ruta base para los archivos
PDF_ROOT = os.path.join(settings.STATIC_PDF, 'pdf')
if not os.path.exists(PDF_ROOT):
    os.makedirs(PDF_ROOT)

def is_safe_path(path):
    """Verifica que la ruta solicitada esté dentro del directorio permitido"""
    requested_path = os.path.abspath(os.path.join(PDF_ROOT, path))
    return requested_path.startswith(PDF_ROOT)

@user_passes_test(lambda user: user.is_superuser)
@ensure_csrf_cookie
def file_manager(request):
    """Vista principal del gestor de archivos"""
    context = {
        'section': 'files',
        'title': 'File Manager'
    }
    return render(request, 'admin/file_management.html', context)

@user_passes_test(lambda user: user.is_superuser)
def list_files(request, subfolder=''):
    """Lista archivos y carpetas en la ruta especificada"""
    try:
        # Construir y verificar la ruta
        current_path = os.path.join(PDF_ROOT, subfolder)
        if not is_safe_path(subfolder):
            return JsonResponse({'error': 'Invalid path'}, status=403)
        
        # Asegurar que la ruta existe
        if not os.path.exists(current_path):
            os.makedirs(current_path)
        
        # Obtener lista de archivos y carpetas
        items = []
        for item in os.listdir(current_path):
            item_path = os.path.join(current_path, item)
            relative_path = os.path.relpath(item_path, PDF_ROOT)
            
            # Ignorar archivos y carpetas ocultos
            if item.startswith('.'):
                continue
                
            items.append({
                'name': item,
                'type': 'folder' if os.path.isdir(item_path) else 'file',
                'size': os.path.getsize(item_path) if os.path.isfile(item_path) else 0,
                'path': relative_path.replace('\\', '/')  # Normalizar separadores para la web
            })
        
        return JsonResponse({
            'items': items,
            'current_path': subfolder
        })
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)

@user_passes_test(lambda user: user.is_superuser)
def create_folder(request):
    """Crea una nueva carpeta"""
    if request.method == 'POST':
        try:
            folder_name = request.POST.get('name')
            parent_folder = request.POST.get('parent', '')
            
            # Validar el nombre de la carpeta
            if not folder_name or '/' in folder_name or '\\' in folder_name:
                return JsonResponse({'error': 'Invalid folder name'}, status=400)
            
            # Construir y verificar la ruta
            folder_path = os.path.join(PDF_ROOT, parent_folder, folder_name)
            if not is_safe_path(os.path.join(parent_folder, folder_name)):
                return JsonResponse({'error': 'Invalid path'}, status=403)
            
            # Crear la carpeta
            os.makedirs(folder_path, exist_ok=True)
            return JsonResponse({'success': True})
            
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)
    
    return JsonResponse({'error': 'Invalid request method'}, status=405)

@user_passes_test(lambda user: user.is_superuser)
def upload_file(request):
    """Sube un archivo al servidor"""
    if request.method == 'POST' and request.FILES.get('file'):
        try:
            file = request.FILES['file']
            folder = request.POST.get('folder', '')
            
            # Validar el nombre del archivo
            if '/' in file.name or '\\' in file.name:
                return JsonResponse({'error': 'Invalid filename'}, status=400)
            
            # Verificar la extensión del archivo (opcional)
            if not file.name.lower().endswith('.pdf'):
                return JsonResponse({'error': 'Only PDF files are allowed'}, status=400)
            
            # Construir y verificar la ruta
            upload_path = os.path.join(PDF_ROOT, folder)
            if not is_safe_path(folder):
                return JsonResponse({'error': 'Invalid path'}, status=403)
            
            # Asegurar que la carpeta existe
            os.makedirs(upload_path, exist_ok=True)
            
            # Guardar el archivo
            fs = FileSystemStorage(location=upload_path)
            filename = fs.save(file.name, file)
            
            return JsonResponse({
                'success': True,
                'filename': filename,
                'size': fs.size(filename)
            })
            
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)
    
    return JsonResponse({'error': 'Invalid request'}, status=400)

@user_passes_test(lambda user: user.is_superuser)
def download_file(request, file_path):
    """Descarga un archivo"""
    try:
        # Verificar la ruta
        if not is_safe_path(file_path):
            raise Http404
        
        full_path = os.path.join(PDF_ROOT, file_path)
        
        # Verificar que el archivo existe y es un archivo
        if not os.path.exists(full_path) or not os.path.isfile(full_path):
            raise Http404
        
        # Abrir y enviar el archivo
        response = FileResponse(open(full_path, 'rb'))
        response['Content-Disposition'] = f'attachment; filename="{os.path.basename(file_path)}"'
        return response
        
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)

@user_passes_test(lambda user: user.is_superuser)
def delete_item(request, item_path):
    """Elimina un archivo o carpeta"""
    if request.method == 'POST':
        try:
            # Remover la barra final si existe
            item_path = item_path.rstrip('/')
            
            # Verificar la ruta
            if not is_safe_path(item_path):
                return JsonResponse({'error': 'Invalid path'}, status=403)
            
            full_path = os.path.join(PDF_ROOT, item_path)
            
            # Verificar que el item existe
            if not os.path.exists(full_path):
                return JsonResponse({'error': 'Item not found'}, status=404)
            
            # Eliminar archivo o carpeta
            if os.path.isfile(full_path):
                os.remove(full_path)
            elif os.path.isdir(full_path):
                try:
                    # Intentar eliminar la carpeta
                    os.rmdir(full_path)
                except OSError as e:
                    if e.errno == errno.ENOTEMPTY:
                        return JsonResponse({
                            'error': 'Cannot delete folder: folder is not empty'
                        }, status=400)
                    raise
            
            return JsonResponse({'success': True})
            
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)
    
    return JsonResponse({'error': 'Invalid request method'}, status=405)

def logout_view(request):
    logout(request)
    return redirect('auth_app:login') 