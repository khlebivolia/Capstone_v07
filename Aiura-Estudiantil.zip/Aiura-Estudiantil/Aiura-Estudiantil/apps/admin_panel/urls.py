from django.urls import path
from . import views

app_name = 'admin_panel' 

urlpatterns = [
    path('', views.admin_dashboard, name='dashboard'),
    
    # Rutas para profesores
    path('teachers/', views.manage_teachers, name='manage_teachers'),
    path('teachers/<int:teacher_id>/edit/', views.edit_teacher, name='edit_teacher'),
    path('teachers/<int:teacher_id>/delete/', views.delete_teacher, name='delete_teacher'),
    
    # Rutas para cursos
    path('courses/', views.manage_courses, name='manage_courses'),
    path('courses/<int:course_id>/edit/', views.edit_course, name='edit_course'),
    path('courses/<int:course_id>/delete/', views.delete_course, name='delete_course'),
    
    # Rutas para estudiantes
    path('students/', views.manage_students, name='manage_students'),
    path('students/<int:student_id>/edit/', views.edit_student, name='edit_student'),
    path('students/<int:student_id>/delete/', views.delete_student, name='delete_student'),

    # Nuevas URLs para la gestión de archivos
    path('files/', views.file_manager, name='file_manager'),  # Vista principal del gestor de archivos
    path('files/list/', views.list_files, name='list_files'),  # Listar archivos en la raíz
    path('files/list/<path:subfolder>/', views.list_files, name='list_files_subfolder'),  # Listar archivos en subcarpeta
    path('files/create-folder/', views.create_folder, name='create_folder'),  # Crear nueva carpeta
    path('files/upload/', views.upload_file, name='upload_file'),  # Subir archivo
    path('files/download/<path:file_path>/', views.download_file, name='download_file'),  # Descargar archivo
    path('files/delete/<path:item_path>/', views.delete_item, name='delete_item'),  # Añadida barra final

    # Ruta de logout
    path('logout/', views.logout_view, name='logout'),
]
