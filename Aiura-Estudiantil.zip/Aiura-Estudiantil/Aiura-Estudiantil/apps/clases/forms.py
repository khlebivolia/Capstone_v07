from django import forms
from apps.admin_panel.models import Alumno, Nota

class StudentForm(forms.ModelForm):
    class Meta:
        model = Alumno
        fields = ['nombre', 'apellido', 'curso']

nota_field = forms.IntegerField(
    widget=forms.NumberInput(attrs={'class': 'form-control', 'min': 10, 'max': 70}),
    required=False
)

class GradeForm(forms.ModelForm):
    nota_1 = nota_field
    nota_2 = nota_field
    nota_3 = nota_field
    nota_4 = nota_field
    nota_5 = nota_field
    final_grade = forms.IntegerField(
        widget=forms.NumberInput(attrs={'class': 'form-control', 'min': 10, 'max': 70, 'readonly': True}),
        required=False
    )

    def __init__(self, data=None, initial=None, *args, **kwargs):
        super().__init__(data, initial, *args, **kwargs)

        if self.instance and self.instance.id:
            self.fields['final_grade'].initial = self.instance.promedio

    def clean(self):
        cleaned_data = super().clean()

        notas = [
            cleaned_data.get('nota_1'),
            cleaned_data.get('nota_2'),
            cleaned_data.get('nota_3'),
            cleaned_data.get('nota_4'),
            cleaned_data.get('nota_5')
        ]

        for index, nota in enumerate(notas, start=1):
            if nota is not None and (nota < 10 or nota > 70):
                raise forms.ValidationError(f"La nota {index} debe estar entre 10 y 70.")

        valid_notes = [note for note in notas if note is not None]
        if valid_notes:
            promedio = round(sum(valid_notes) / len(valid_notes), 0)
            self.cleaned_data['final_grade'] = promedio
        else:
            self.cleaned_data['final_grade'] = None

        return cleaned_data

    class Meta:
        model = Nota
        fields = ['nota_1', 'nota_2', 'nota_3', 'nota_4', 'nota_5', 'final_grade']
