from datetime import date, datetime, timedelta
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db.models import Count, Exists, Sum, Avg
from django.db.models import OuterRef, Subquery
from django.shortcuts import get_object_or_404, render, redirect
from apps.admin_panel.models import Alumno, Asistencia, Curso, Nota, Profesor
from apps.planificacion.models import Planificacion
from .forms import GradeForm
from django.db.models import Exists, OuterRef

# funcion para mostrar la pagina principal del profesor
@login_required
def dashboard(request):
    try:
        teacher = request.user.profesor

        courses = teacher.cursos.all()
        total_courses = courses.count()
        total_students = Alumno.objects.filter(curso__profesores=teacher).distinct().count()
        # Obtener planificaciones del profesor
        planificaciones = Planificacion.objects.filter(profesor=teacher)
        total_planificaciones = planificaciones.count()
        
        context = {
            'teacher': teacher,
            'courses': courses,
            'total_courses': total_courses,
            'total_students': total_students,
            'total_planificaciones': total_planificaciones,
        }
        return render(request, 'classroom/dashboard.html', context)
    
    except Profesor.DoesNotExist:
        messages.error(request, "No se encontró el perfil de profesor para este usuario.")
        return redirect('classroom:dashboard')

# funcion para mostrar la lista de los curos
@login_required
def lista_cursos(request):
    courses = Curso.objects.filter(profesores__user=request.user).annotate(
        student_count=Count('alumno')
    )

    total_students = courses.aggregate(total=Sum('student_count'))['total'] or 0

    context = {
        'courses': courses,
        'total_students': total_students,
    }
    return render(request, 'classroom/lista_cursos.html', context)

# funcion para visualizar las calificaciones de los estudiantes
@login_required
def notas_estudiantes(request, course_id):
    course = get_object_or_404(Curso, id=course_id, profesores=request.user.profesor)

    final_grade_subquery = Nota.objects.filter(
        alumno=OuterRef('pk'),
        curso=course
    ).values('final_grade')[:1]

    students = Alumno.objects.filter(curso=course).annotate(
        final_grade=Subquery(final_grade_subquery)
    )

    context = {
        'course': course,
        'students': students,
    }
    return render(request, 'classroom/notas_estudiantes.html', context)

# funcion para actualizar las calificaciones
@login_required
def actualizar_notas(request, course_id, student_id):
    student = get_object_or_404(Alumno, id=student_id, curso__profesores=request.user.profesor)
    try:
        nota = student.notas.get(curso_id=course_id)
    except Nota.DoesNotExist:
        nota = Nota.objects.create(alumno=student, curso_id=course_id)
    if request.method == 'POST':
        form = GradeForm(request.POST, instance=nota)
        if form.is_valid():
            form.save()
            messages.success(request, 'Notas Guardadas.')
            return redirect('classroom:notas_estudiantes', course_id=student.curso.id)
    else:
        form = GradeForm(instance=nota)
    
    context = {
        'form': form,
        'student': student,
    }
    return render(request, 'classroom/actualizar_notas.html', context)

# funcion para pasara Asistencia
@login_required
def pasar_asistencia(request, course_id):
    course = get_object_or_404(Curso, id=course_id, profesores=request.user.profesor)
    
    # Obtener fecha del query parameter o usar la fecha actual
    selected_date = request.GET.get('date')
    try:
        selected_date = datetime.strptime(selected_date, '%Y-%m-%d').date() if selected_date else date.today()
    except ValueError:
        selected_date = date.today()
    
    # Obtener fechas únicas donde hay registros de asistencia para este curso
    registered_dates = Asistencia.objects.filter(
        alumno__curso=course
    ).values_list('fecha', flat=True).distinct().order_by('-fecha')

    # Asegurarse de que la fecha actual esté disponible en el selector
    today = date.today()
    date_choices = list(registered_dates)
    if today not in date_choices:
        date_choices.insert(0, today)

    # Obtener las asistencias existentes para la fecha seleccionada
    existing_attendances = Asistencia.objects.filter(
        alumno__curso=course,
        fecha=selected_date
    )

    # Crear un diccionario con las asistencias existentes
    students = Alumno.objects.filter(curso=course)
    students_with_attendance = []
    
    for student in students:
        attendance = existing_attendances.filter(alumno=student).first()
        students_with_attendance.append({
            'student': student,
            'is_present': attendance.asistio if attendance else False
        })

    if request.method == 'POST':
        for student in students:
            status = request.POST.get(f'attendance_{student.id}', 'absent') == 'present'
            Asistencia.objects.update_or_create(
                alumno=student,
                fecha=selected_date,
                defaults={'asistio': status},
            )
        messages.success(request, f'Asistencia actualizada para {selected_date}.')
        return redirect('classroom:pasar_asistencia', course_id=course_id)

    context = {
        'course': course,
        'students_with_attendance': students_with_attendance,
        'selected_date': selected_date,
        'date_choices': date_choices,
    }
    return render(request, 'classroom/pasar_asistencia.html', context)

@login_required
def ver_asistencias(request, course_id):
    course = get_object_or_404(Curso, id=course_id, profesores=request.user.profesor)
    
    # Obtener rango de fechas del formulario o usar el mes actual
    start_date = request.GET.get('start_date')
    end_date = request.GET.get('end_date')
    
    try:
        start_date = datetime.strptime(start_date, '%Y-%m-%d').date() if start_date else date.today().replace(day=1)
        end_date = datetime.strptime(end_date, '%Y-%m-%d').date() if end_date else date.today()
    except ValueError:
        start_date = date.today().replace(day=1)
        end_date = date.today()

    # Obtener todos los alumnos y sus asistencias en el rango de fechas
    students = Alumno.objects.filter(curso=course)
    attendance_data = {}
    
    for student in students:
        attendance_data[student.id] = {
            'student': student,
            'attendance': Asistencia.objects.filter(
                alumno=student,
                fecha__range=[start_date, end_date]
            ).order_by('fecha')
        }

    context = {
        'course': course,
        'attendance_data': attendance_data,
        'start_date': start_date,
        'end_date': end_date,
    }
    return render(request, 'classroom/ver_asistencias.html', context)

def detalle_curso(request, course_id):
    try:
        # Verificar que el curso pertenece al profesor actual
        curso = get_object_or_404(Curso, id=course_id, profesores=request.user.profesor)
        
        # Obtener todos los alumnos del curso
        alumnos = Alumno.objects.filter(curso=curso)
        alumnos_data = []
        
        for alumno in alumnos:
            # Calcular notas para cada alumno
            notas = Nota.objects.filter(alumno=alumno, curso=curso)
            promedio = notas.aggregate(Avg('final_grade'))['final_grade__avg'] or 0
            
            # Calcular asistencias para cada alumno
            asistencias = Asistencia.objects.filter(alumno=alumno)
            total_asistencias = asistencias.count()
            presentes = asistencias.filter(asistio=True).count()
            ausentes = total_asistencias - presentes
            
            # Agregar datos de cada alumno
            alumnos_data.append({
                'nombre': alumno.get_full_name(),
                'promedio': round(promedio, 2),
                'total_asistencias': total_asistencias,
                'presentes': presentes,
                'ausentes': ausentes
            })
        
        context = {
            'curso': curso,
            'alumnos': alumnos_data,
        }
        
        return render(request, 'classroom/detalle_curso.html', context)
    
    except Profesor.DoesNotExist:
        messages.error(request, "No se encontró el perfil de profesor para este usuario.")
        return redirect('classroom:dashboard')