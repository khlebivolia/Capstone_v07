from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.shortcuts import redirect, render
from apps.admin_panel.models import Profesor  # Ajusta la importación según la ubicación de tu modelo Profesor
from django.contrib.auth.decorators import login_required

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        # Autenticar al usuario en la tabla User de Django
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            login(request, user)
            
            # Verificar si el usuario es superusuario o staff (por ejemplo, superadmin)
            if user.is_superuser or user.is_staff:
                return redirect('admin_panel:dashboard')  # Redirige al panel de administración
            
            # Si no es superusuario o staff, verificar si el username está en la tabla Profesor
            elif Profesor.objects.filter(user__username=username).exists():
                return redirect('classroom:dashboard')  # Redirige a la vista del profesor
            
            else:
                messages.error(request, 'No tiene permisos para acceder a esta sección')
        else:
            messages.error(request, 'Usuario o contraseña incorrectos')
    
    return render(request, 'auth/login.html')


@login_required
def logout_view(request):
    logout(request)
    return redirect('auth_app:login')