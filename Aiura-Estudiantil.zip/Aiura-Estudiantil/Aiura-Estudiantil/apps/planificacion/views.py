import os
import re
import tiktoken
import threading
import json
import calendar
import requests
from datetime import datetime, timedelta
from typing import List, Dict, Tuple
from django.core.cache import cache
from django.template.loader import render_to_string
from django.views.decorators.http import require_http_methods
from django.shortcuts import render, get_object_or_404
from django.http import JsonResponse, HttpResponse
from django.conf import settings
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from apps.admin_panel.models import Profesor
from .models import Planificacion, DiaPlanificacion, Observacion
from langchain_community.chat_models import ChatOpenAI
from langchain_community.document_loaders import PyPDFLoader
from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import OpenAIEmbeddings
from langchain.chains import RetrievalQA
from langchain_community.chat_message_histories import ChatMessageHistory
from langchain.memory import ConversationBufferMemory
from langchain.schema import Document
from langchain.schema.messages import HumanMessage, AIMessage  # Añadido HumanMessage y AIMessage
from openai import OpenAIError  # Remover este import
from openai import APIError, APIConnectionError, APITimeoutError, AuthenticationError, RateLimitError, OpenAIError
from xhtml2pdf import pisa
from django.urls import path
from io import BytesIO

# Variable global para almacenar el vectorstore
vectorstore = None
vectorstore_lock = threading.Lock()
chat_memories = {} 

def index(request):
    return render(request, 'planner/planning.html')

def get_or_create_memory(session_id):
    if session_id not in chat_memories:
        message_history = ChatMessageHistory()
        chat_memories[session_id] = ConversationBufferMemory(
            chat_memory=message_history,
            return_messages=True,
            memory_key="chat_history",
            k=5  # Keep last 5 interactions
        )
    return chat_memories[session_id]

def count_tokens(text, model_name="gpt-4o-mini"):
    encoding = tiktoken.encoding_for_model(model_name)
    return len(encoding.encode(text))

@login_required
def ver_planes(request):
    try:
        profesor = request.user.profesor
        planes = Planificacion.objects.filter(profesor=profesor)
        return render(request, 'planner/ver_planes.html', {'planes': planes})
    except Profesor.DoesNotExist:
        raise PermissionDenied("No tienes perfil de profesor")
    
@login_required
@require_http_methods(["POST"])
def agregar_comentario(request, dia_id):
    try:
        profesor = request.user.profesor
        dia = get_object_or_404(DiaPlanificacion, id=dia_id)
        
        # Verificar que el plan pertenece al profesor actual
        if dia.planificacion.profesor != profesor:
            raise PermissionDenied("No tienes acceso a este plan")
            
        datos = json.loads(request.body)
        dia.comentario = datos.get('comentario', '')
        dia.save()
        return JsonResponse({'estado': 'exitoso'})
    except Profesor.DoesNotExist:
        raise PermissionDenied("No tienes perfil de profesor")

@login_required
@require_http_methods(["POST"])
def generar_observacion(request, plan_id):
    plan = get_object_or_404(Planificacion, id=plan_id)
    dias = plan.dias.all()
    
    # Preparar contexto para la IA
    contexto = f"""
        Genera una observación estructurada y profesional del siguiente plan de clases.
        NO uses markdown, asteriscos (**) ni hashtags (#) en tu respuesta.
        La observación debe seguir exactamente este formato sin ningún tipo de marcado especial:

        ASPECTOS GENERALES:
        [Observaciones sobre la estructura general del plan y su alineación con los objetivos incluyendo los comentarios]

        FORTALEZAS IDENTIFICADAS:
        1. [Primera fortaleza]
        2. [Segunda fortaleza]
        3. [Tercera fortaleza]

        ÁREAS DE MEJORA:
        1. [Primera sugerencia de mejora]
        2. [Segunda sugerencia de mejora]
        3. [Tercera sugerencia de mejora]

        RECOMENDACIONES ESPECÍFICAS:
        1. [Primera recomendación concreta]
        2. [Segunda recomendación concreta]
        3. [Tercera recomendación concreta]

        CONCLUSIÓN:
        [Síntesis final y perspectivas futuras]

        Datos del plan:
        Materia: {plan.materia}
        Curso: {plan.curso}
        Periodo: {plan.periodo}
        
        Detalles por día:
        """
    
    for dia in dias:
        contexto += f"""
        Semana {dia.semana}, Día {dia.dia}:
        Contenido: {dia.contenido}
        Comentario: {dia.comentario or 'Sin comentarios'}
        """
    
    try:
        llm = ChatOpenAI(
            openai_api_key=settings.OPENAI_API_KEY,
            model_name='gpt-4o-mini',
            temperature=0.7,
        )
        
        observacion = llm.predict(contexto + "\n\nGenera una observación general del plan y sus comentarios:")
        
        nueva_observacion = Observacion.objects.create(
            planificacion=plan,
            contenido=observacion
        )
        
        return JsonResponse({
            'observacion': observacion,
            'observacion_id': nueva_observacion.id
        })
        
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)

@login_required
@require_http_methods(["POST"])
def generar_observacion_dia(request, dia_id):
    dia = get_object_or_404(DiaPlanificacion, id=dia_id)
    
    # Verificar que el plan pertenece al profesor actual
    if dia.planificacion.profesor != request.user.profesor:
        raise PermissionDenied("No tienes acceso a este plan")
    
    # Preparar contexto para la IA
    contexto = f"""
        Genera una observación estructurada y profesional para este día de clase específico, y que responda al comentario escrito por el profesor el cual es el siguiente: {dia.comentario or 'Sin comentarios'} .
        NO uses markdown, asteriscos (**) ni hashtags (#) en tu respuesta.
        La observación debe seguir exactamente este formato sin ningún tipo de marcado especial:

        ANÁLISIS DEL CONTENIDO:
        [Análisis detallado del contenido del día y su relevancia]

        ALINEACIÓN DE OBJETIVOS:
        [Evaluación de cómo los objetivos de aprendizaje se alinean con el contenido y las actividades]

        EFECTIVIDAD DE LA ACTIVIDAD:
        [Evaluación de la actividad planificada y su relación con los objetivos]

        SUGERENCIAS DE MEJORA:
        1. [Primera sugerencia específica]
        2. [Segunda sugerencia específica]
        3. [Tercera sugerencia específica]

        APLICACION DE LA MEJORA:
        1. aqui describe como aplicar la mejora sugeridad



        Datos del día:
        Semana: {dia.semana}
        Día: {dia.dia}
        Contenido: {dia.contenido}
        Objetivos: {dia.objetivos}
        Resumen: {dia.resumen}
        Actividad: {dia.actividad}
        Comentario del profesor: {dia.comentario or 'Sin comentarios'}
        """
    
    try:
        llm = ChatOpenAI(
            openai_api_key=settings.OPENAI_API_KEY,
            model_name='gpt-4o-mini',
            temperature=0.7,
        )
        
        observacion = llm.predict(contexto)
        
        # Guardar la observación en el día
        dia.observacion = observacion
        dia.save()
        
        return JsonResponse({
            'observacion': observacion,
            'dia_id': dia.id
        })
        
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)
    
@login_required
def descargar_plan_pdf(request, plan_id):
    try:
        profesor = request.user.profesor
        plan = get_object_or_404(Planificacion, id=plan_id)
        
        # Verificar que el plan pertenece al profesor actual
        if plan.profesor != profesor:
            raise PermissionDenied("No tienes acceso a este plan")
            
        dias = plan.dias.all()
        ultima_observacion = plan.observaciones.order_by('-creado_el').first()

        # Preparar el contexto con los datos formateados
        context = {
            'plan': plan,
            'dias': dias,
            'observacion': ultima_observacion,
            'fecha_actual': datetime.now().strftime("%d/%m/%Y")
        }

        # Renderizar el template a HTML
        html_string = render_to_string('planner/pdf_template.html', context)
        
        # Configurar la respuesta HTTP
        response = HttpResponse(content_type='application/pdf')
        response['Content-Disposition'] = f'attachment; filename=Plan_{plan.curso}_{plan.materia}.pdf'
        
        # Crear el PDF
        pisa_status = pisa.CreatePDF(
            html_string,
            dest=response,
            encoding='UTF-8'
        )

        if pisa_status.err:
            return HttpResponse('Hubo un error al generar el PDF', status=500)
        
        return response
        
    except Profesor.DoesNotExist:
        raise PermissionDenied("No tienes perfil de profesor")
    
@login_required
@require_http_methods(["POST"])
def eliminar_plan(request, plan_id):
    try:
        profesor = request.user.profesor
        plan = get_object_or_404(Planificacion, id=plan_id)
        
        # Verificar que el plan pertenece al profesor actual
        if plan.profesor != profesor:
            raise PermissionDenied("No tienes acceso a este plan")
            
        plan.delete()
        return JsonResponse({'success': True, 'message': 'Plan eliminado correctamente'})
        
    except Profesor.DoesNotExist:
        raise PermissionDenied("No tienes perfil de profesor")
    except Planificacion.DoesNotExist:
        return JsonResponse({'error': 'Plan no encontrado'}, status=404)
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)

@login_required
def generate_plan(request):
    if request.method == 'POST':
        try:
            # Verificar que el usuario tiene un perfil de profesor
            try:
                profesor = request.user.profesor  # Obtener el profesor asociado al usuario
            except Profesor.DoesNotExist:
                return JsonResponse({'error': 'Usuario no tiene perfil de profesor'})

            materia = request.POST.get('materia')
            periodo = request.POST.get('periodo')
            dias_clases = request.POST.get('dias_clases')
            curso = request.POST.get('curso')
            dias_semana = request.POST.getlist('dias_semana')
            descripcion = request.POST.get('descripcion')
            continue_generation = request.POST.get('continue_generation') == 'true'
            session_id = request.session.session_key or request.session.create()

            if not all([materia, periodo, dias_clases, curso, dias_semana]):
                return JsonResponse({'error': 'Todos los campos son obligatorios.'})
                
            if len(dias_semana) != int(dias_clases):
                return JsonResponse({'error': 'La cantidad de días seleccionados no coincide.'})
            
            # Obtener fechas del período
            año_actual = datetime.now().year
            fecha_inicio, fecha_fin = obtener_fechas_periodo(periodo, año_actual)
            
            # Obtener fechas válidas de clase
            fechas_validas = obtener_fechas_clases_validas(fecha_inicio, fecha_fin, dias_semana)

            # Obtener fechas válidas primero


            # Agrupar fechas por semana
            fechas_por_semana = {}
            for fecha in fechas_validas:
                num_semana = (fecha - fecha_inicio).days // 7 + 1
                if num_semana not in fechas_por_semana:
                    fechas_por_semana[num_semana] = []
                fechas_por_semana[num_semana].append(fecha)

            # Cargar el vectorstore
            vs = load_or_create_vectorstore(curso, materia)
            if vs is None:
                return JsonResponse({'error': 'No se pudo cargar o crear el vectorstore.'})

            memory = get_or_create_memory(session_id)
            temp_plan = request.session.get('temp_plan', {}).get('contenido', '')

            # Obtener contenido relevante de los PDFs
            retriever = vs.as_retriever(search_kwargs={"k": 5})
            docs = retriever.get_relevant_documents(f"contenido sobre {materia} para {curso}")
            
            # Preparar el contexto de los PDFs y recopilar referencias
            pdf_references = {}
            pdf_context = []
            
            for doc in docs:
                filename = doc.metadata['filename']
                page = doc.metadata.get('page_number', 1)
                content = doc.page_content.strip()
                
                pdf_context.append(f"Del archivo '{filename}', página {page}:\n{content}")
                
                # Registrar referencias de PDFs
                if filename not in pdf_references:
                    pdf_references[filename] = {'paginas_usadas': set()}
                pdf_references[filename]['paginas_usadas'].add(page)

            pdf_content = "\n\n".join(pdf_context)

            if continue_generation:
                # Extraer la última semana y día del plan actual
                ultima_semana = 1
                ultimo_dia = 0
                
                if temp_plan:
                    # Buscar la última semana mencionada
                    semana_matches = re.finditer(r'Semana (\d+)', temp_plan)
                    ultima_semana = max([int(match.group(1)) for match in semana_matches], default=1)
                    
                    # Buscar el último día mencionado en la última semana
                    dia_pattern = fr"Semana {ultima_semana}.*?Día (\d+)"
                    dia_matches = re.finditer(dia_pattern, temp_plan, re.DOTALL)
                    ultimo_dia = max([int(match.group(1)) for match in dia_matches], default=0)

                prompt = f"""
                Analiza este contenido de los PDFs:
                {pdf_content}

                Continúa con la siguiente planificación de clases para la materia {materia}, curso {curso}, durante el {periodo}.
                
                El plan contempla {dias_clases} días de clases a la semana.

                Las clases se realizarán en los siguientes días:
                {', '.join([f"{dict(Planificacion.DIAS_SEMANA)[dia]}" for dia in dias_semana])}
                
                PLAN ACTUAL:
                {temp_plan}
                
                Por favor, continúa desde la Semana {ultima_semana}, comenzando con el Día {ultimo_dia + 1}.
                
                IMPORTANTE:
                - Para cada contenido que generes, DEBES indicar la fuente:
                  * Si usas información de los PDFs, indica: "Fuente: [nombre del archivo PDF], página [número]"
                  * Si generas contenido nuevo, indica: "(Generado por OpenAI)"
                
                Mantén el mismo formato:
                {' '.join([f'''
                #### Semana {semana}
                ''' + '\n'.join([f'''
                **Día {idx + 1} ({fecha.strftime('%d/%m/%Y')}):**
                - **Contenido:** [tema]
                - **Resumen:** [resumen detallado]
                - **Actividad:** [actividad práctica]
                - **Objetivos de Aprendizaje:**
                1. [Primer objetivo específico y medible]
                2. [Segundo objetivo específico y medible]
                3. [Tercer objetivo específico y medible (opcional)]
                **Fuente: [archivo], página [número]**
                ''' for idx, fecha in enumerate(fechas)]) for semana, fechas in fechas_por_semana.items()])}
                """
            else:
                prompt = f"""
                Analiza primero este contenido de los PDFs:
                {pdf_content}

                Genera un plan de clases para la materia **{materia}**, curso **{curso}**, durante un **{periodo}**.

                Las clases se realizarán en los siguientes días:
                {', '.join([f"{dict(Planificacion.DIAS_SEMANA)[dia]}" for dia in dias_semana])}
                
                Instrucciones estrictas:
                1. Para cada contenido que generes, DEBES indicar la fuente:
                   * Si usas información de los PDFs, indica: "Fuente: [nombre del archivo PDF]"
                   * Si generas contenido nuevo, indica: "(Generado por OpenAI)"
                2. Al especificar los objetivos de aprendizaje, deben ser:
                   * Específicos y medibles
                   * Orientados a resultados concretos
                   * Alineados con el contenido del día
                   * Enfocados en habilidades o conocimientos verificables
                   * 2-3 objetivos por día

                Fechas de inicio y Término de Semestre
                Primer Semestre:
                Inicio: 01 de Marzo
                Término: 18 de Junio

                Segundo Semestre:
                Inicio: 08 de Julio
                Término: 19 de Diciembre

                Fechas de inicio y Término de Trimestre
                Primer Trimestre:
                Inicio: 05 de Marzo
                termino: 30 de Mayo

                Segundo Trimestre:
                Inicio: 03 de Junio
                Término: 13 de Septiembre

                Tercer Trimestre:
                Inicio: 16 de Septiembre
                Término: 19 de Diciembre

                considera esta fecha para generar las semanas correspondiente

                El plan debe contemplar **{dias_clases} días de clases a la semana**. Para **cada día de clase**, necesito:

                - Un tema del contenido
                - Un resumen detallado
                - Una actividad práctica
                - Objetivos de Aprendizaje específicos para la clase

                **Descripción adicional:** {descripcion}

                ---
                ### Plan de Clases de {materia} - {curso} ({periodo})
                
                {' '.join([f'''
                #### Semana {semana}
                ''' + '\n'.join([f'''
                **Día {idx + 1} ({fecha.strftime('%d/%m/%Y')}):**
                - **Contenido:** [tema]
                - **Resumen:** [resumen detallado]
                - **Actividad:** [actividad práctica]
                - **Objetivos de Aprendizaje:**
                1. [Primer objetivo específico y medible]
                2. [Segundo objetivo específico y medible]
                3. [Tercer objetivo específico y medible (opcional)]
                **Fuente: [archivo]**
                ''' for idx, fecha in enumerate(fechas)]) for semana, fechas in fechas_por_semana.items()])}


                *(Repetir hasta completar {dias_clases} días por semana)*
                """

            try:
                llm = ChatOpenAI(
                    api_key=settings.OPENAI_API_KEY,
                    model_name='gpt-4o-mini',
                    temperature=0.7,
                )

                qa_chain = RetrievalQA.from_chain_type(
                    llm=llm,
                    chain_type="stuff",
                    retriever=retriever,
                    memory=memory
                )

                response = qa_chain.invoke({"query": prompt})
                generated_plan = response.get('result', '')

                if isinstance(generated_plan, str) and generated_plan.strip() != "":
                    # Si es continuación, concatenar con el plan existente
                    if continue_generation and temp_plan:
                        final_plan = temp_plan + "\n\n" + generated_plan
                    else:
                        final_plan = generated_plan

                    # Guardar en la sesión
                    request.session['temp_plan'] = {
                        'profesor_id': profesor.id,
                        'materia': materia,
                        'curso': curso,
                        'periodo': periodo,
                        'dias_clases': dias_clases,
                        'dias_semana': dias_semana,  # Agregar los días seleccionados
                        'descripcion': descripcion,
                        'contenido': final_plan
                    }

                    # Preparar las referencias de PDF para la respuesta
                    pdf_refs_for_response = {
                        filename: {
                            'paginas_usadas': sorted(list(data['paginas_usadas'])),
                            'total_paginas': len(data['paginas_usadas'])
                        }
                        for filename, data in pdf_references.items()
                    }
                    
                    return JsonResponse({
                        'plan': format_generated_plan(generated_plan),
                        'temp': True,
                        'pdf_references': pdf_refs_for_response
                    })
                else:
                    return JsonResponse({'error': 'El plan generado no es válido o está vacío.'})

            except AuthenticationError:
                return JsonResponse({'error': 'Error de autenticación con OpenAI. Verifique su API key.'})
            except RateLimitError:
                return JsonResponse({'error': 'Se ha excedido el límite de solicitudes a OpenAI. Intente más tarde.'})
            except APITimeoutError:
                return JsonResponse({'error': 'Tiempo de espera agotado. La solicitud a OpenAI tomó demasiado tiempo.'})
            except APIConnectionError:
                return JsonResponse({'error': 'Error de conexión con la API de OpenAI. Verifique su conexión a internet.'})
            except OpenAIError as e:
                return JsonResponse({'error': f'Error en la API de OpenAI: {str(e)}'})
            except Exception as e:
                return JsonResponse({'error': f'Error inesperado en la generación: {str(e)}'})

        except Exception as e:
            return JsonResponse({'error': f'Error inesperado: {str(e)}'})

    return render(request, 'planner/planning.html')

def obtener_feriados_chile(año: int) -> list:
    """Obtiene feriados de Chile con caché y datos de respaldo"""
    cache_key = f'feriados_chile_{año}'
    feriados = cache.get(cache_key)
    
    if feriados:
        return [datetime.strptime(fecha, '%Y-%m-%d').date() for fecha in feriados]

    # Datos de respaldo para feriados comunes
    feriados_respaldo = {
        '2024': [
            '2024-01-01',  # Año Nuevo
            '2024-03-29',  # Viernes Santo
            '2024-03-30',  # Sábado Santo
            '2024-05-01',  # Día del Trabajo
            '2024-05-21',  # Día de las Glorias Navales
            '2024-06-29',  # San Pedro y San Pablo
            '2024-07-16',  # Día de la Virgen del Carmen
            '2024-08-15',  # Asunción de la Virgen
            '2024-09-18',  # Independencia Nacional
            '2024-09-19',  # Día de las Glorias del Ejército
            '2024-10-12',  # Encuentro de Dos Mundos
            '2024-11-01',  # Día de Todos los Santos
            '2024-12-08',  # Inmaculada Concepción
            '2024-12-25',  # Navidad
        ]
    }

    try:
        response = requests.get(
            f"https://apis.digital.gob.cl/fl/feriados/{año}",
            timeout=5
        )
        if response.status_code == 200:
            datos_feriados = response.json()
            feriados = [feriado['fecha'] for feriado in datos_feriados]
        else:
            feriados = feriados_respaldo.get(str(año), [])
    except:
        feriados = feriados_respaldo.get(str(año), [])

    # Guardar en caché por 24 horas
    cache.set(cache_key, feriados, 86400)
    
    return [datetime.strptime(fecha, '%Y-%m-%d').date() for fecha in feriados]

def obtener_fechas_periodo(periodo: str, año: int) -> Tuple[datetime, datetime]:
    """Obtiene las fechas de inicio y fin según el período seleccionado"""
    fechas = {
        'Primer Semestre': ('03-01', '06-18'),
        'Segundo Semestre': ('07-08', '12-19'),
        'Primer Trimestre': ('03-05', '05-30'),
        'Segundo Trimestre': ('06-03', '09-13'),
        'Tercer Trimestre': ('09-16', '12-19')
    }
    
    fecha_inicio_str, fecha_fin_str = fechas[periodo]
    fecha_inicio = datetime.strptime(f"{año}-{fecha_inicio_str}", '%Y-%m-%d').date()
    fecha_fin = datetime.strptime(f"{año}-{fecha_fin_str}", '%Y-%m-%d').date()
    
    return fecha_inicio, fecha_fin

def obtener_fechas_clases_validas(fecha_inicio: datetime, fecha_fin: datetime, 
                                dias_seleccionados: List[str]) -> List[datetime]:
    """Obtiene todas las fechas válidas de clase excluyendo feriados"""
    feriados = obtener_feriados_chile(fecha_inicio.year)
    if fecha_inicio.year != fecha_fin.year:
        feriados.extend(obtener_feriados_chile(fecha_fin.year))
    
    mapeo_dias = {
        'LU': 0, 'MA': 1, 'MI': 2, 'JU': 3, 'VI': 4
    }
    
    numeros_dias_seleccionados = [mapeo_dias[dia] for dia in dias_seleccionados]
    fecha_actual = fecha_inicio
    fechas_validas = []
    
    while fecha_actual <= fecha_fin:
        if (fecha_actual.weekday() in numeros_dias_seleccionados and 
            fecha_actual not in feriados):
            fechas_validas.append(fecha_actual)
        fecha_actual += timedelta(days=1)
    
    return fechas_validas

def format_generated_plan(plan):
    """Formatea el plan generado para visualización"""
    lines = plan.split('\n')
    formatted_lines = []
    current_section = None
    is_first_week = True
    in_objectives = False
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
            
        # Manejo de ambos formatos de día
        day_formats = [
            r'\*\*Día \d+\*\*',           # Formato: **Día 1**
            r'\*\*Día \d+ \(\d{2}/\d{2}/\d{4}\)\:\*\*'  # Formato: **Día 1 (27/11/2024):**
        ]
        
        if line.startswith('###') or line.startswith('####'):
            title = line.replace('###', '').replace('####', '').strip()
            formatted_lines.append(f'<h3 class="text-2xl font-bold mb-6">{title}</h3>')
            
        elif ('Semana' in line and not any(section in line for section in 
            ['Contenido:', 'Resumen:', 'Actividad:', 'Objetivos de Aprendizaje:'])):
            if not is_first_week:
                formatted_lines.append('<hr class="my-6 border-t border-gray-300">')
            else:
                is_first_week = False
            
            semana = line.replace('# ', '').replace('#', '').replace('Semana', '').strip()
            formatted_lines.append(f'<h4 class="text-xl font-bold my-4">Semana {semana}</h4>')
            formatted_lines.append('<div class="ml-4">')
            
        elif any(re.match(pattern, line) for pattern in day_formats) or line.startswith('Día'):
            if current_section:
                formatted_lines.append('</div>')
                current_section = None
            
            # Extraer fecha si existe
            fecha_match = re.search(r'\((\d{2}/\d{2}/\d{4})\)', line)
            fecha_str = f' <span class="text-purple-600">({fecha_match.group(1)})</span>' if fecha_match else ''
            
            day = re.sub(r'\*\*|\(.*\)|\:', '', line).strip()
            formatted_lines.append('<div class="mb-6">')
            formatted_lines.append(f'<h5 class="text-lg font-semibold mt-4 mb-2">{day}{fecha_str}</h5>')
            current_section = 'day'
            
        elif any(section in line for section in ['Contenido:', 'Resumen:', 'Actividad:', 'Objetivos de Aprendizaje:']):
            in_objectives = 'Objetivos de Aprendizaje:' in line
            line = line.lstrip('- ').replace('**', '')
            section = line.split(':')[0].strip()
            content = line.split(':', 1)[1].strip() if ':' in line else ''
            
            formatted_lines.append(f'<div class="mb-3">')
            formatted_lines.append(f'<strong class="block text-gray-700 mb-1">{section}:</strong>')
            if content:
                if in_objectives:
                    formatted_lines.append('<div class="pl-4 text-gray-600 space-y-2">')
                else:
                    formatted_lines.append(f'<div class="pl-4 text-gray-600">{content}</div>')
            formatted_lines.append('</div>')
                
        elif line:
            content = line.replace('**', '').lstrip('- ').strip()
            if content:
                if in_objectives:
                    formatted_lines.append(f'<div class="flex items-start mb-2">')
                    formatted_lines.append(f'<i class="ph ph-check-circle text-purple-500 mr-2 mt-1"></i>')
                    formatted_lines.append(f'<p>{content}</p>')
                    formatted_lines.append('</div>')
                else:
                    formatted_lines.append(f'<div class="pl-4 text-gray-600">{content}</div>')

    if current_section:
        formatted_lines.append('</div>')
    formatted_lines.append('</div>')
    
    result = '\n'.join(formatted_lines)
    return result

def parsear_contenido_plan(contenido):
    """Parsea el contenido del plan"""
    dias = []
    semana_actual = None
    dia_actual = None
    seccion_actual = None
    contenido_acumulado = []
    
    for linea in contenido.split('\n'):
        linea = linea.strip()
        
        if not linea:
            continue
            
        # Detectar semana
        if 'Semana' in linea:
            coincidencia_semana = re.search(r'Semana (\d+)', linea)
            if coincidencia_semana:
                semana_actual = int(coincidencia_semana.group(1))
                
        # Detectar día y fecha
        elif 'Día' in linea:
            if dia_actual is not None and seccion_actual:
                dias[-1][seccion_actual] = '\n'.join(contenido_acumulado).strip()
            
            coincidencia_dia = re.search(r'Día (\d+)', linea)
            coincidencia_fecha = re.search(r'\((\d{2}/\d{2}/\d{4})\)', linea)
            
            if coincidencia_dia:
                dia_actual = int(coincidencia_dia.group(1))
                fecha = None
                if coincidencia_fecha:
                    fecha = datetime.strptime(coincidencia_fecha.group(1), '%d/%m/%Y').date()
                
                dias.append({
                    'semana': semana_actual,
                    'dia': dia_actual,
                    'fecha': fecha,
                    'contenido': '',
                    'resumen': '',
                    'actividad': '',
                    'objetivos': ''
                })
                seccion_actual = None
                contenido_acumulado = []
                
        elif semana_actual is not None and dia_actual is not None:
            if 'Contenido:' in linea:
                if seccion_actual:
                    dias[-1][seccion_actual] = '\n'.join(contenido_acumulado).strip()
                seccion_actual = 'contenido'
                contenido_acumulado = [linea.replace('Contenido:', '').strip()]
            elif 'Resumen:' in linea:
                if seccion_actual:
                    dias[-1][seccion_actual] = '\n'.join(contenido_acumulado).strip()
                seccion_actual = 'resumen'
                contenido_acumulado = [linea.replace('Resumen:', '').strip()]
            elif 'Actividad:' in linea:
                if seccion_actual:
                    dias[-1][seccion_actual] = '\n'.join(contenido_acumulado).strip()
                seccion_actual = 'actividad'
                contenido_acumulado = [linea.replace('Actividad:', '').strip()]
            elif 'Objetivos de Aprendizaje:' in linea:
                if seccion_actual:
                    dias[-1][seccion_actual] = '\n'.join(contenido_acumulado).strip()
                seccion_actual = 'objetivos'
                contenido_acumulado = [linea.replace('Objetivos de Aprendizaje:', '').strip()]
            elif seccion_actual:
                contenido_limpio = re.sub(r'^[-*]\s*', '', linea).strip()
                if contenido_limpio:
                    contenido_acumulado.append(contenido_limpio)
    
    if dias and seccion_actual:
        dias[-1][seccion_actual] = '\n'.join(contenido_acumulado).strip()
    
    return dias

@login_required
def ver_plan_detalle(request, plan_id):
    try:
        profesor = request.user.profesor
        plan = get_object_or_404(Planificacion, id=plan_id)
        
        if plan.profesor != profesor:
            raise PermissionDenied("No tienes acceso a este plan")
            
        dias = plan.dias.all().order_by('semana', 'dia')
        
        # Obtener días seleccionados como lista
        dias_seleccionados = plan.dias_seleccionados.split(',') if plan.dias_seleccionados else []
        
        # Obtener fechas válidas
        fechas_validas = list(obtener_fechas_clases_validas(
            plan.fecha_inicio, 
            plan.fecha_termino, 
            dias_seleccionados
        ))
        
        dias_data = []
        for i, dia in enumerate(dias):
            fecha = fechas_validas[i] if i < len(fechas_validas) else None
            
            dias_data.append({
                'id': dia.id,
                'semana': dia.semana,
                'dia': dia.dia,
                'fecha': fecha.strftime('%d/%m/%Y') if fecha else None,
                'contenido': dia.contenido,
                'resumen': dia.resumen,
                'actividad': dia.actividad,
                'objetivos': dia.objetivos,
                'comentario': dia.comentario,
                'es_feriado': fecha in obtener_feriados_chile(fecha.year) if fecha else False
            })
            
        ultima_observacion = plan.observaciones.order_by('-creado_el').first()
        
        data = {
            'id': plan.id,
            'materia': plan.materia,
            'curso': plan.curso,
            'periodo': plan.periodo,
            'dias_clases': plan.dias_clases,
            'dias_seleccionados': dias_seleccionados,
            'descripcion': plan.descripcion,
            'dias': dias_data,
            'observacion': ultima_observacion.contenido if ultima_observacion else None,
            'fecha_inicio': plan.fecha_inicio.strftime('%d/%m/%Y'),
            'fecha_termino': plan.fecha_termino.strftime('%d/%m/%Y')
        }
        
        return JsonResponse(data)
        
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)
    
@login_required
@require_http_methods(["POST"])
def guardar_plan(request):
    try:
        profesor = request.user.profesor
    except Profesor.DoesNotExist:
        return JsonResponse({'error': 'Usuario no tiene perfil de profesor'}, status=403)
        
    temp_plan = request.session.get('temp_plan')
    
    if not temp_plan:
        return JsonResponse({'error': 'No hay plan temporal para guardar'}, status=400)
    
    try:
        # Obtener fechas del período
        año_actual = datetime.now().year
        fecha_inicio, fecha_termino = obtener_fechas_periodo(temp_plan['periodo'], año_actual)
        dias_semana = temp_plan.get('dias_semana', [])

        # Obtener todas las fechas válidas y feriados
        fechas_validas = obtener_fechas_clases_validas(fecha_inicio, fecha_termino, dias_semana)
        feriados = obtener_feriados_chile(año_actual)

        # Crear el plan
        nuevo_plan = Planificacion.objects.create(
            profesor=profesor,
            materia=temp_plan['materia'],
            curso=temp_plan['curso'],
            periodo=temp_plan['periodo'],
            dias_clases=temp_plan['dias_clases'],
            dias_seleccionados=','.join(dias_semana),
            descripcion=temp_plan['descripcion'],
            contenido=temp_plan['contenido'],
            fecha_inicio=fecha_inicio,
            fecha_termino=fecha_termino
        )

        # Parsear los días del plan
        dias_parseados = parsear_contenido_plan(temp_plan['contenido'])
        
        # Crear los días de planificación con sus fechas correspondientes
        for dia, fecha in zip(dias_parseados, fechas_validas):
            es_feriado = fecha in feriados
            
            DiaPlanificacion.objects.create(
                planificacion=nuevo_plan,
                semana=dia['semana'],
                dia=dia['dia'],
                fecha=fecha,
                contenido=dia['contenido'],
                resumen=dia['resumen'],
                actividad=dia['actividad'],
                objetivos=dia['objetivos'],
                comentario=None,
                es_feriado=es_feriado
            )

        # Limpiar el plan temporal
        del request.session['temp_plan']
        
        return JsonResponse({
            'success': True,
            'plan_id': nuevo_plan.id,
            'message': 'Plan guardado exitosamente'
        })
        
    except Exception as e:
        return JsonResponse({
            'error': f'Error al guardar el plan: {str(e)}'
        }, status=500)
    

def load_or_create_vectorstore(curso, materia):
    global vectorstore
    with vectorstore_lock:
        vectorstore_name = f"{curso}_{materia}_vectorstore"
        vectorstore_path = os.path.join(settings.BASE_DIR, 'faiss_index', vectorstore_name)
        
        if vectorstore is None or not os.path.exists(os.path.join(vectorstore_path, "index.faiss")):
            print(f"Cargando o creando el vectorstore para {curso} - {materia}...")

            try:
                pdf_folder = os.path.join(settings.BASE_DIR, 'static', 'PDF', curso, materia)
                documents = []

                if not os.path.exists(pdf_folder):
                    print(f'La carpeta de PDFs para {curso} - {materia} no existe.')
                    return None

                for filename in os.listdir(pdf_folder):
                    if filename.endswith(".pdf"):
                        pdf_path = os.path.join(pdf_folder, filename)
                        loader = PyPDFLoader(pdf_path)
                        pages = loader.load()
                        full_text = "\n".join([page.page_content for page in pages])
                        document = Document(page_content=full_text, metadata={"filename": filename})
                        documents.append(document)

                embeddings = OpenAIEmbeddings(
                    openai_api_key=settings.OPENAI_API_KEY,
                    model="text-embedding-ada-002",
                    show_progress_bar=True,
                    chunk_size=1000,
                    request_timeout=60
                )

                if documents:
                    vectorstore = FAISS.from_documents(documents, embeddings)
                    os.makedirs(vectorstore_path, exist_ok=True)
                    vectorstore.save_local(vectorstore_path)
                    print(f"El vectorstore para {curso} - {materia} se creó y guardó correctamente.")
                else:
                    print(f"No se encontraron documentos para procesar en {pdf_folder}")
                    return None

            except Exception as e:
                import traceback
                traceback.print_exc()
                print(f'Error al cargar o crear el vectorstore: {e}')
                return None
        else:
            try:
                embeddings = OpenAIEmbeddings(
                    openai_api_key=settings.OPENAI_API_KEY,
                    model="text-embedding-ada-002"
                )
                # Agregar allow_dangerous_deserialization=True ya que sabemos que los archivos son seguros
                vectorstore = FAISS.load_local(
                    vectorstore_path, 
                    embeddings,
                    allow_dangerous_deserialization=True  # Agregada esta línea
                )
                print(f"El vectorstore para {curso} - {materia} se cargó correctamente desde disco.")
            except Exception as e:
                print(f'Error al cargar el vectorstore existente: {e}')
                return None
    
    return vectorstore