from django.db import models
from apps.admin_panel.models import Profesor

class Planificacion(models.Model):
    DIAS_SEMANA = [
        ('LU', 'Lunes'),
        ('MA', 'Martes'),
        ('MI', 'Miércoles'),
        ('JU', 'Jueves'),
        ('VI', 'Viernes')
    ]
    
    profesor = models.ForeignKey(Profesor, on_delete=models.CASCADE, related_name='planificaciones')
    materia = models.CharField(max_length=100)
    curso = models.CharField(max_length=100)
    periodo = models.CharField(max_length=50)
    dias_clases = models.IntegerField()
    dias_seleccionados = models.CharField(max_length=100)  # Almacenado como valores separados por comas
    descripcion = models.TextField()
    contenido = models.TextField()
    creado_el = models.DateTimeField(auto_now_add=True)
    fecha_inicio = models.DateField()
    fecha_termino = models.DateField()

    class Meta:
        ordering = ['-creado_el']
        verbose_name = 'Planificación'
        verbose_name_plural = 'Planificaciones'

    def __str__(self):
        return f"{self.materia} - {self.curso} ({self.periodo}) - Prof. {self.profesor}"

class DiaPlanificacion(models.Model):
    planificacion = models.ForeignKey(Planificacion, on_delete=models.CASCADE, related_name='dias')
    semana = models.IntegerField()
    dia = models.IntegerField()
    fecha = models.DateField(null=True, blank=True)  # Nueva campo
    contenido = models.TextField()
    resumen = models.TextField()
    actividad = models.TextField()
    objetivos = models.TextField()  # Cambiado de lectura a objetivos
    comentario = models.TextField(blank=True, null=True)
    observacion = models.TextField(blank=True, null=True)  # Nueva campo para la observación del día
    es_feriado = models.BooleanField(default=False)  # Nuevo campo
    
    class Meta:
        ordering = ['semana', 'dia']
        verbose_name = 'Día de Planificación'
        verbose_name_plural = 'Días de Planificación'

    def __str__(self):
        return f"Semana {self.semana} - Día {self.dia} ({self.planificacion})"
    
class Observacion(models.Model):
    planificacion = models.ForeignKey(Planificacion, on_delete=models.CASCADE, related_name='observaciones')
    contenido = models.TextField()
    creado_el = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-creado_el']
        verbose_name = 'Observación'
        verbose_name_plural = 'Observaciones'

    def __str__(self):
        return f"Observación - {self.planificacion} ({self.creado_el.strftime('%d/%m/%Y')})"
