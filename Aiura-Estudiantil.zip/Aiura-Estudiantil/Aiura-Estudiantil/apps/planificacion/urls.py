from django.urls import path
from . import views

app_name = 'planner'

urlpatterns = [
    path('', views.index, name='index'),
    path('generate_plan/', views.generate_plan, name='generate_plan'),
    path('descargar_plan_pdf/<int:plan_id>/', views.descargar_plan_pdf, name='descargar_plan_pdf'),
    path('ver_planes/', views.ver_planes, name='ver_planes'),
    path('ver_plan/<int:plan_id>/', views.ver_plan_detalle, name='ver_plan_detalle'),
    path('agregar_comentario/<int:dia_id>/', views.agregar_comentario, name='agregar_comentario'),
    path('generar_observacion/<int:plan_id>/', views.generar_observacion, name='generar_observacion'),
    path('guardar_plan/', views.guardar_plan, name='guardar_plan'),
    path('eliminar_plan/<int:plan_id>/', views.eliminar_plan, name='eliminar_plan'),
    path('generar_observacion_dia/<int:dia_id>/', views.generar_observacion_dia, name='generar_observacion_dia'),
]