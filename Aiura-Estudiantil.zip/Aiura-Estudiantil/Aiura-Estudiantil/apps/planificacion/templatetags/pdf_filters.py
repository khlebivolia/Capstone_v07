# apps/planificacion/templatetags/pdf_filters.py
from django import template
import re

register = template.Library()

@register.filter
def split(value, arg):
    return value.split(arg)

@register.filter
def matches(value, pattern):
    return bool(re.match(pattern, value))