// Función para obtener el token CSRF de las cookies
function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let cookie of cookies) {
            cookie = cookie.trim();
            if (cookie.startsWith(name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

const csrftoken = getCookie('csrftoken');

let planIdAEliminar = null;
// Event Listener principal para cuando el DOM está cargado
document.addEventListener('DOMContentLoaded', function() {
    // Manejador para el botón de ver detalles
    const botonesVerDetalles = document.querySelectorAll('.btn-ver-detalles');
    botonesVerDetalles.forEach(boton => {
        boton.addEventListener('click', function() {
            const planId = this.dataset.planId;
            cargarDetallesPlan(planId);
        });
    });

    // Manejador para el botón de generar observación
    const botonObservacion = document.querySelector('.btn-generar-observacion');
    if (botonObservacion) {
        botonObservacion.addEventListener('click', function() {
            const planId = this.dataset.planId;
            generarObservacion(planId);
        });
    }

    // Event listeners para los botones de eliminar
    const botonesEliminar = document.querySelectorAll('.btn-eliminar');
    botonesEliminar.forEach(boton => {
        boton.addEventListener('click', function() {
            const planId = this.dataset.planId;
            confirmarEliminar(planId);
        });
    });

    // Event listener para el botón de continuar generando
    const continueButton = document.getElementById('continueButton');
    if (continueButton) {
        continueButton.addEventListener('click', () => generarPlan(true));
    }

    // Event listener para el botón de guardar
    const saveButton = document.getElementById('saveButton');
    if (saveButton) {
        saveButton.addEventListener('click', guardarPlan);
    }

    // Inicializar manejadores de eventos para los comentarios
    const comentariosInputs = document.querySelectorAll('.comentario-input');
    comentariosInputs.forEach(input => {
        input.addEventListener('change', manejarCambioComentario);
    });

    // Event listeners para el modal de eliminación
    const btnCancelarEliminar = document.getElementById('btnCancelarEliminar');
    const btnConfirmarEliminar = document.getElementById('btnConfirmarEliminar');
    
    if (btnCancelarEliminar) {
        btnCancelarEliminar.addEventListener('click', cerrarModal);
    }
    
    if (btnConfirmarEliminar) {
        btnConfirmarEliminar.addEventListener('click', function() {
            if (planIdAEliminar) {
                eliminarPlan(planIdAEliminar);
            }
        });
    }
});

// Función principal para generar el plan
document.getElementById('planningForm').onsubmit = function(event) {
    event.preventDefault();
    generarPlan(false);
};

// Funciones para eliminar planificación
function confirmarEliminar(planId) {
    planIdAEliminar = planId;
    document.getElementById('modalConfirmacion').classList.remove('hidden');
}

function cerrarModal() {
    document.getElementById('modalConfirmacion').classList.add('hidden');
    planIdAEliminar = null;
}

function eliminarPlan(planId) {
    fetch(`/planificacion/eliminar_plan/${planId}/`, {
        method: 'POST',
        headers: {
            'X-CSRFToken': csrftoken,
            'Content-Type': 'application/json'
        },
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Remover la tarjeta del plan eliminado
            const planCard = document.querySelector(`[data-plan-id="${planId}"]`).closest('.bg-white');
            planCard.remove();
            
            // Cerrar el modal
            cerrarModal();
            
            // Verificar si no quedan planes
            const planesRestantes = document.querySelectorAll('.bg-white').length;
            if (planesRestantes === 0) {
                location.reload(); // Recargar para mostrar el mensaje de "No tienes planificaciones"
            }
        } else {
            throw new Error(data.error || 'Error al eliminar el plan');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error al eliminar el plan: ' + error.message);
        cerrarModal();
    });
}

// Función mejorada para generar planes
// Función para mostrar las referencias de PDFs

// Función para extraer referencias de PDFs del contenido generado
function extraerReferenciasPDF(contenido) {
    const referencias = {};
    const regex = /Fuente:\s*([^,]+),\s*página\s*(\d+)/g;
    let match;

    while ((match = regex.exec(contenido)) !== null) {
        const [, archivo, pagina] = match;
        const nombreArchivo = archivo.trim();
        const numeroPagina = parseInt(pagina);

        if (!referencias[nombreArchivo]) {
            referencias[nombreArchivo] = {
                paginas_usadas: new Set(),
                total_paginas: 0
            };
        }
        referencias[nombreArchivo].paginas_usadas.add(numeroPagina);
    }

    // Convertir los Sets a arrays y calcular totales
    for (const archivo in referencias) {
        referencias[archivo].paginas_usadas = Array.from(referencias[archivo].paginas_usadas).sort((a, b) => a - b);
        referencias[archivo].total_paginas = referencias[archivo].paginas_usadas.length;
    }

    return referencias;
}

// Función actualizada para mostrar las referencias de PDFs
function mostrarReferenciaPDFs(pdfReferences, contenido) {
    const plansContent = document.getElementById('plansContent');
    const existingPdfInfo = document.querySelector('.pdf-references-info');
    
    if (existingPdfInfo) {
        existingPdfInfo.remove();
    }

    // Combinar referencias del backend con las extraídas del contenido
    const referenciasDelContenido = extraerReferenciasPDF(contenido);
    const referenciasCompletas = { ...pdfReferences };

    // Actualizar las referencias con la información extraída del contenido
    for (const archivo in referenciasDelContenido) {
        if (!referenciasCompletas[archivo]) {
            referenciasCompletas[archivo] = referenciasDelContenido[archivo];
        } else {
            // Combinar páginas usadas
            const todasLasPaginas = new Set([
                ...referenciasCompletas[archivo].paginas_usadas,
                ...referenciasDelContenido[archivo].paginas_usadas
            ]);
            referenciasCompletas[archivo].paginas_usadas = Array.from(todasLasPaginas).sort((a, b) => a - b);
            referenciasCompletas[archivo].total_paginas = todasLasPaginas.size;
        }
    }

    if (Object.keys(referenciasCompletas).length === 0) return;

    const pdfInfoHTML = `
        <div class="pdf-references-info bg-blue-50 rounded-xl p-6 border-2 border-blue-200 shadow-lg mb-6">
            <div class="flex items-center space-x-4 mb-4">
                <div class="bg-blue-100 rounded-full p-3 shadow-inner">
                    <i class="ph ph-file-pdf text-blue-600 text-2xl"></i>
                </div>
                <div>
                    <h4 class="text-lg font-semibold text-blue-900">Fuentes de Contenido</h4>
                    <p class="text-sm text-blue-600">PDFs consultados para esta planificación</p>
                </div>
            </div>
            <div class="space-y-3">
                ${Object.entries(referenciasCompletas).map(([filename, data]) => `
                    <div class="bg-white rounded-lg p-4 border border-blue-200">
                        <div class="flex items-center justify-between">
                            <div class="flex items-center space-x-3">
                                <i class="ph ph-file-text text-blue-500 text-xl"></i>
                                <span class="font-medium text-gray-700">${filename}</span>
                            </div>
                            <div class="text-sm text-blue-600">
                                <span class="bg-blue-100 px-3 py-1 rounded-full">
                                    
                                </span>
                            </div>
                        </div>
                        <div class="mt-2 text-sm text-gray-600">
                        
                        </div>
                    </div>
                `).join('')}
            </div>
        </div>
    `;

    plansContent.insertAdjacentHTML('afterbegin', pdfInfoHTML);
}
// Actualizar la función generarPlan para incluir el contenido generado
function generarPlan(continueGeneration = false) {
    const loadingIcon = document.getElementById('loadingIcon');
    const generatedPlans = document.getElementById('generatedPlans');
    
    loadingIcon.style.display = 'block';

    const formData = new FormData(document.getElementById('planningForm'));
    formData.append('continue_generation', continueGeneration);

    fetch("/planificacion/generate_plan/", {
        method: 'POST',
        body: formData,
        headers: {
            'X-CSRFToken': csrftoken
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`Error en la respuesta del servidor: ${response.status} ${response.statusText}`);
        }
        return response.json();
    })
    .then(data => {
        loadingIcon.style.display = 'none';

        if (data.plan) {
            const plansContent = document.getElementById('plansContent');
            
            if (continueGeneration) {
                plansContent.innerHTML += `
                    <div class="mt-4 border-t pt-4">
                        ${data.plan}
                    </div>
                `;
            } else {
                plansContent.innerHTML = `
                    <div>
                        ${data.plan}
                    </div>
                `;
            }

            // Mostrar referencias de PDFs incluyendo el contenido generado
            if (data.pdf_references) {
                mostrarReferenciaPDFs(data.pdf_references, data.plan);
            }
            
            generatedPlans.style.display = 'block';
            const btnContainer = document.getElementById('btnContainer');
            btnContainer.style.display = 'flex';
            document.getElementById('continueButton').style.display = 'block';
            document.getElementById('saveButton').style.display = 'block';
            
            if (continueGeneration) {
                plansContent.scrollTop = plansContent.scrollHeight;
            }
        } else if (data.error) {
            alert("Error: " + data.error);
        }
    })
    .catch(error => {
        loadingIcon.style.display = 'none';
        alert("Hubo un error: " + error.message);
    });
}
// Nueva función para guardar el plan
function guardarPlan() {
    fetch("/planificacion/guardar_plan/", {
        method: 'POST',
        headers: {
            'X-CSRFToken': csrftoken,
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Plan guardado exitosamente');
            // Limpiar la interfaz después de guardar
            document.getElementById('plansContent').innerHTML = '';
            document.getElementById('btnContainer').style.display = 'none';
            // Opcional: redireccionar a la página de ver planes
            // window.location.href = '/planificacion/ver_planes/';
        } else {
            throw new Error(data.error || 'Error al guardar el plan');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error al guardar el plan: ' + error.message);
    });
}
// Lógica para prevalidar y filtrar materias basado en el curso seleccionado
document.getElementById('curso').addEventListener('change', function() {
    var selectedCurso = this.value;
    var materias = document.querySelectorAll('#materia option');

    materias.forEach(function(materia) {
        if (materia.getAttribute('data-curso') === selectedCurso || materia.value === "") {
            materia.style.display = 'block';
        } else {
            materia.style.display = 'none';
        }
    });

    document.getElementById('materia').value = "";
});
// Función para redirigir al usuario a la página de visualización de planes
document.getElementById('viewPlansButton').addEventListener('click', function() {
    window.location.href = "/planificacion/ver_planes/";
});
// Función para cargar los detalles de un plan específico
function cargarDetallesPlan(planId) {
    const contenedor = document.getElementById('detallesPlan');
    if (!contenedor) return;
    
    contenedor.style.display = 'block';
    contenedor.innerHTML = '<div class="text-center"><div class="loader"></div><p>Cargando detalles...</p></div>';
    
    fetch(`/planificacion/ver_plan/${planId}/`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al cargar los detalles del plan');
            }
            return response.json();
        })
        .then(data => {
            contenedor.innerHTML = '';

            // Crear selector de días
            const selectorContainer = document.createElement('div');
            selectorContainer.className = 'selector-dias mb-4';
            selectorContainer.innerHTML = `
                <label class="form-label">Seleccionar día:</label>
                <select class="form-select" id="selectDia">
                    <option value="">Seleccione un día</option>
                    ${data.dias.map(dia => `
                        <option value="${dia.id}" data-comentado="${dia.comentario ? 'true' : 'false'}">
                            Semana ${dia.semana} - Día ${dia.dia}
                            ${dia.comentario ? '✓' : ''}
                        </option>
                    `).join('')}
                </select>
            `;
            contenedor.appendChild(selectorContainer);

            // Contenedor para el día seleccionado
            const diaContainer = document.createElement('div');
            diaContainer.id = 'diaSeleccionado';
            contenedor.appendChild(diaContainer);

            // Contenedor para el botón de observación
            const observacionContainer = document.createElement('div');
            observacionContainer.id = 'observacionContainer';
            observacionContainer.className = 'mt-4';
            contenedor.appendChild(observacionContainer);

            // Event listener para el selector
            const selector = contenedor.querySelector('#selectDia');
            selector.addEventListener('change', function() {
                const diaId = this.value;
                if (diaId) {
                    const diaSeleccionado = data.dias.find(d => d.id.toString() === diaId);
                    mostrarDiaSeleccionado(diaSeleccionado);
                } else {
                    document.getElementById('diaSeleccionado').innerHTML = '';
                }
                actualizarEstadoObservacion(selector, planId);
            });

            // Mostrar observación existente si hay
            if (data.observacion) {
                mostrarObservacion(data.observacion);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            contenedor.innerHTML = `
                <div class="bg-red-50 border-2 border-red-200 rounded-xl p-6 shadow-lg">
                    <div class="flex items-center space-x-4">
                        <div class="bg-red-100 rounded-full p-3 shadow-inner">
                            <i class="ph ph-warning-circle text-red-600 text-2xl"></i>
                        </div>
                        <div>
                            <h4 class="text-lg font-semibold text-red-900 mb-1">
                                Error al Cargar el Plan
                            </h4>
                            <p class="text-red-600">
                                No se pudieron cargar los detalles. Por favor, intente nuevamente.
                            </p>
                        </div>
                    </div>
                </div>
            `;
        });
}

// function mostrarDiaSeleccionado(dia) {
//     const contenedor = document.getElementById('diaSeleccionado');
    
//     // Función para limpiar texto de asteriscos y guiones
//     const limpiarTexto = (texto) => {
//         return texto
//             .replace(/\*{4,}/g, '')  // Elimina los asteriscos
//             .replace(/^- /, '')      // Elimina el guión inicial
//             .trim();                 // Elimina espacios extras
//     };

//     contenedor.innerHTML = `
//         <div class="bg-white rounded-xl p-6 border-2 border-purple-100 shadow-lg mb-6 hover:shadow-xl transition-shadow">
//             <!-- Encabezado del día -->
//             <div class="bg-purple-50 rounded-xl p-4 mb-6 border-2 border-purple-200">
//                 <h4 class="text-xl font-bold text-purple-900 flex items-center">
//                     <i class="ph ph-calendar-check text-2xl text-purple-600 mr-3"></i>
//                     Semana ${dia.semana} - Día ${dia.dia}
//                 </h4>
//             </div>
            
//             <!-- Sección Contenido -->
//             <div class="bg-white rounded-xl p-6 border-2 border-purple-100 shadow-sm hover:shadow-md transition-shadow mb-6">
//                 <h3 class="text-xl font-bold text-purple-900 mb-4 flex items-center">
//                     <i class="ph ph-book-open text-2xl text-purple-600 mr-3"></i>
//                     Contenido
//                 </h3>
//                 <p class="text-gray-700 text-lg pl-9">${limpiarTexto(dia.contenido)}</p>
//             </div>
            
//             <!-- Sección Resumen -->
//             <div class="bg-white rounded-xl p-6 border-2 border-purple-100 shadow-sm hover:shadow-md transition-shadow mb-6">
//                 <h3 class="text-xl font-bold text-purple-900 mb-4 flex items-center">
//                     <i class="ph ph-clipboard-text text-2xl text-purple-600 mr-3"></i>
//                     Resumen
//                 </h3>
//                 <p class="text-gray-700 text-lg pl-9">${limpiarTexto(dia.resumen)}</p>
//             </div>
            
//             <!-- Sección Actividad -->
//             <div class="bg-white rounded-xl p-6 border-2 border-purple-100 shadow-sm hover:shadow-md transition-shadow mb-6">
//                 <h3 class="text-xl font-bold text-purple-900 mb-4 flex items-center">
//                     <i class="ph ph-target text-2xl text-purple-600 mr-3"></i>
//                     Actividad
//                 </h3>
//                 <p class="text-gray-700 text-lg pl-9">${limpiarTexto(dia.actividad)}</p>
//             </div>
            
//             <!-- Sección Objetivos de Aprendizaje -->
//             <div class="bg-white rounded-xl p-6 border-2 border-purple-100 shadow-sm hover:shadow-md transition-shadow mb-6">
//                 <h3 class="text-xl font-bold text-purple-900 mb-4 flex items-center">
//                     <i class="ph ph-target text-2xl text-purple-600 mr-3"></i>
//                     Objetivos de Aprendizaje
//                 </h3>
//                 <div class="text-gray-700 text-lg pl-9">
//                     ${dia.objetivos.split('\n')
//                         .map(objetivo => objetivo.trim())
//                         .filter(objetivo => objetivo && objetivo.length > 1)
//                         .map(objetivo => 
//                             `<p class="mb-2">${limpiarTexto(objetivo)}</p>`
//                         ).join('')}
//                 </div>
//             </div>

//             <!-- Sección Comentarios -->
//             <div class="bg-purple-50 rounded-xl p-8 border-2 border-purple-200 shadow-lg mb-6">
//                 <div class="flex items-center mb-6">
//                     <div class="bg-purple-200 rounded-full p-3">
//                         <i class="ph ph-chat-circle-text text-purple-700 text-3xl"></i>
//                     </div>
//                     <div class="ml-4">
//                         <h3 class="text-xl font-bold text-purple-900">Comentarios y Notas</h3>
//                         <p class="text-purple-600 mt-1">Registra tus observaciones sobre esta clase</p>
//                     </div>
//                 </div>
                
//                 <div class="bg-white rounded-xl p-6 shadow-md">
//                     <textarea
//                         class="w-full p-4 text-gray-700 bg-gray-50 border-2 border-purple-200 rounded-xl
//                                focus:ring-4 focus:ring-purple-500 focus:border-purple-500
//                                min-h-[150px] text-lg placeholder-gray-500 resize-y comentario-input mb-4"
//                         placeholder="Escribe aquí tus notas y comentarios sobre la clase..."
//                         data-dia-id="${dia.id}"
//                     >${dia.comentario || ''}</textarea>
                    
//                     <div class="flex items-center space-x-4">
//                         <button 
//                             class="btn-guardar-comentario inline-flex items-center px-6 py-3 
//                                    bg-purple-600 text-white rounded-xl hover:bg-purple-700 
//                                    transition-all transform hover:scale-105 hover:shadow-lg 
//                                    active:scale-95 text-lg font-medium"
//                             data-dia-id="${dia.id}"
//                         >
//                             <i class="ph ph-check-circle text-xl mr-2"></i>
//                             Guardar Comentario
//                         </button>
//                         <span class="mensaje-guardado hidden text-green-600 font-medium flex items-center">
//                             <i class="ph ph-check-circle text-xl mr-2"></i>
//                             Comentario guardado
//                         </span>
//                     </div>
//                 </div>
//             </div>

//             <!-- Sección Observación AI -->
//             <div class="bg-emerald-50 rounded-xl p-8 border-2 border-emerald-200 shadow-lg">
//                 <div class="flex items-center mb-6">
//                     <div class="bg-emerald-200 rounded-full p-3">
//                         <i class="ph ph-sparkle text-emerald-700 text-3xl"></i>
//                     </div>
//                     <div class="ml-4">
//                         <h3 class="text-xl font-bold text-emerald-900">Observación IA</h3>
//                         <p class="text-emerald-600 mt-1">Análisis y sugerencias generadas por IA</p>
//                     </div>
//                 </div>

//                 ${dia.observacion ? `
//                     <div class="bg-white rounded-xl p-6 shadow-md mb-4">
//                         <div class="text-gray-700 space-y-3 prose prose-emerald max-w-none">
//                             ${dia.observacion.split('\n').map(parrafo => `<p>${parrafo}</p>`).join('')}
//                         </div>
//                     </div>
//                 ` : ''}

//                 <button 
//                     class="btn-generar-observacion-dia inline-flex items-center px-6 py-3 
//                            bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 
//                            transition-all transform hover:scale-105 hover:shadow-lg 
//                            active:scale-95 text-lg font-medium"
//                     data-dia-id="${dia.id}"
//                 >
//                     <i class="ph ph-robot text-xl mr-2"></i>
//                     ${dia.observacion ? 'Regenerar Observación' : 'Generar Observación'}
//                 </button>
//             </div>
//         </div>
//     `;

//     // Agregar event listener para el botón de guardar comentario
//     const botonGuardar = contenedor.querySelector('.btn-guardar-comentario');
//     botonGuardar.addEventListener('click', function() {
//         const textarea = this.parentElement.parentElement.querySelector('textarea');
//         const mensajeGuardado = this.nextElementSibling;
//         guardarComentario(dia.id, textarea.value, mensajeGuardado, true);
//     });

//     // Agregar event listener para el botón de generar observación
//     const botonObservacion = contenedor.querySelector('.btn-generar-observacion-dia');
//     botonObservacion.addEventListener('click', function() {
//         generarObservacionDia(dia.id);
//     });
// }

function configurarEventListeners(contenedor, planId) {
    // Event listeners para botones de guardar comentario
    const botonesGuardar = contenedor.querySelectorAll('.btn-guardar-comentario');
    botonesGuardar.forEach(boton => {
        boton.addEventListener('click', function() {
            const diaId = this.dataset.diaId;
            const textarea = this.parentElement.previousElementSibling;
            const mensajeGuardado = this.nextElementSibling;
            guardarComentario(diaId, textarea.value, mensajeGuardado);
        });
    });
 
    // Event listener para botón de observación
    const botonObservacion = contenedor.querySelector('.btn-generar-observacion');
    if (botonObservacion) {
        botonObservacion.addEventListener('click', function() {
            generarObservacion(planId);
        });
    }
}

function mostrarObservacion(observacion) {
    const contenedorObservacion = document.createElement('div');
    contenedorObservacion.className = 'contenedor-observacion mt-4 p-4 border rounded bg-light';
    
    // Limpiar y formatear el texto de la observación
    const observacionFormateada = observacion
        .split('\n')
        .map(parrafo => {
            // Eliminar asteriscos
            parrafo = parrafo.replace(/\*{2}/g, '');
            
            if (parrafo.match(/^\d+\./)) {
                return `<div class="observacion-item border-start border-primary ps-3 mb-3">${parrafo}</div>`;
            }
            return `<p>${parrafo}</p>`;
        })
        .join('');

        contenedorObservacion.innerHTML = `
        <div class="bg-purple-50 rounded-lg p-4 mb-6">
            <div class="flex items-center space-x-4">
                <div class="bg-purple-100 rounded-full p-3 shadow-inner">
                    <i class="ph ph-clipboard-text text-purple-600 text-2xl"></i>
                </div>
                <div class="flex-1">
                    <h4 class="text-lg font-semibold text-purple-900 mb-1">
                        Observación General del Plan
                    </h4>
                    <div class="flex items-center text-sm text-purple-600">
                        <i class="ph ph-sparkle text-purple-500 mr-2"></i>
                        <span>Análisis y Recomendaciones</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="text-gray-700 space-y-3 pl-4 prose prose-purple max-w-none observacion-contenido">
            ${observacionFormateada}
        </div>
    `;
    
    const observacionExistente = document.querySelector('.contenedor-observacion');
    if (observacionExistente) {
        observacionExistente.remove();
    }
    
    document.getElementById('detallesPlan').appendChild(contenedorObservacion);
}

function guardarComentario(diaId, comentario, mensajeElement, actualizarSelector = false) {
    fetch(`/planificacion/agregar_comentario/${diaId}/`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCookie('csrftoken')
        },
        body: JSON.stringify({ comentario })
    })
    .then(response => {
        if (!response.ok) throw new Error('Error al guardar el comentario');
        return response.json();
    })
    .then(data => {
        mensajeElement.style.display = 'inline-block';
        setTimeout(() => {
            mensajeElement.style.display = 'none';
        }, 3000);

        if (actualizarSelector) {
            const option = document.querySelector(`#selectDia option[value="${diaId}"]`);
            if (option && comentario.trim()) {
                option.dataset.comentado = 'true';
                if (!option.textContent.includes('✓')) {
                    option.textContent += ' ✓';
                }
            } else if (option && !comentario.trim()) {
                option.dataset.comentado = 'false';
                option.textContent = option.textContent.replace(' ✓', '');
            }
            actualizarEstadoObservacion(document.getElementById('selectDia'));
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error al guardar el comentario');
    });
}

function actualizarEstadoObservacion(selector, planId) {
    const options = Array.from(selector.options).slice(1); // Excluir la opción "Seleccione un día"
    const todosComentados = options.every(option => option.dataset.comentado === 'true');
    const observacionContainer = document.getElementById('observacionContainer');
    
    if (todosComentados) {
        if (!document.querySelector('.btn-generar-observacion')) {
            const botonObservacion = document.createElement('button');
            botonObservacion.className = 'btn-generar-observacion btn btn-primary';
            botonObservacion.textContent = 'Generar Observación';
            botonObservacion.onclick = () => generarObservacion(planId);
            observacionContainer.appendChild(botonObservacion);
        }
    } else {
        const botonExistente = document.querySelector('.btn-generar-observacion');
        if (botonExistente) {
            botonExistente.remove();
        }
    }
}

function generarObservacion(planId) {
    // Crear y mostrar el loader
    const detallesPlan = document.getElementById('detallesPlan');
    const loaderHTML = `
        <div class="temp-loader text-center p-4">
            <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
            <p class="text-gray-600">Generando observación...</p>
        </div>
    `;
    
    // Insertar el loader después del contenedor de observaciones
    const observacionContainer = document.getElementById('observacionContainer');
    observacionContainer.insertAdjacentHTML('afterend', loaderHTML);

    fetch(`/planificacion/generar_observacion/${planId}/`, {
        method: 'POST',
        headers: {
            'X-CSRFToken': getCookie('csrftoken')
        }
    })
    .then(response => response.json())
    .then(data => {
        // Remover el loader
        const loader = document.querySelector('.temp-loader');
        if (loader) {
            loader.remove();
        }

        if (data.observacion) {
            const contenedorObservacion = document.createElement('div');
            contenedorObservacion.className = 'contenedor-observacion mt-4 p-4 border rounded bg-light';
            
            // Formatear el texto de la observación
            const observacionFormateada = data.observacion
                .split('\n')
                .map(parrafo => {
                    // Manejar elementos numerados
                    if (parrafo.match(/^\d+\./)) {
                        return `<p class="observacion-item">${parrafo}</p>`;
                    }
                    // Manejar texto en negrita
                    parrafo = parrafo.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
                    return `<p>${parrafo}</p>`;
                })
                .join('');

                contenedorObservacion.innerHTML = `
                <div class="bg-purple-50 rounded-lg p-4 mb-6">
                    <div class="flex items-center space-x-4">
                        <div class="bg-purple-100 rounded-full p-3 shadow-inner">
                            <i class="ph ph-clipboard-text text-purple-600 text-2xl"></i>
                        </div>
                        <div>
                            <h4 class="text-lg font-semibold text-purple-900">
                                Observación General
                            </h4>
                        </div>
                    </div>
                </div>
                <div class="text-gray-700 space-y-3 pl-4 prose prose-purple max-w-none observacion-contenido">
                    ${observacionFormateada}
                </div>
            `;
            
            // Buscar si ya existe una observación y reemplazarla
            const observacionExistente = document.querySelector('.contenedor-observacion');
            if (observacionExistente) {
                observacionExistente.remove();
            }
            
            document.getElementById('detallesPlan').appendChild(contenedorObservacion);
        } else {
            alert('Error al generar la observación');
        }
    })
    .catch(error => {
        // Remover el loader en caso de error
        const loader = document.querySelector('.temp-loader');
        if (loader) {
            loader.remove();
        }
        
        console.error('Error:', error);
        alert('Error al generar la observación');
    });
}

// actualacion de funciones
function mostrarObservacionDia(observacion) {
    return `
        <div class="bg-green-50 rounded-lg p-6 border-2 border-green-200 shadow-lg">
            <div class="flex items-center space-x-4 mb-4">
                <div class="bg-green-100 rounded-full p-3 shadow-inner">
                    <i class="ph ph-clipboard-text text-green-600 text-2xl"></i>
                </div>
                <div>
                    <h4 class="text-lg font-semibold text-green-900">
                        Observación del Día
                    </h4>
                </div>
            </div>
            <div class="text-gray-700 space-y-3 pl-4 prose prose-green max-w-none">
                ${observacion.split('\n').map(parrafo => `<p>${parrafo}</p>`).join('')}
            </div>
        </div>
    `;
}

function generarObservacionDia(diaId) {
    const diaContainer = document.getElementById('diaSeleccionado');
    
    // Mostrar loader
    const loaderHTML = `
        <div class="temp-loader text-center p-4">
            <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto mb-4"></div>
            <p class="text-gray-600">Generando observación del día...</p>
        </div>
    `;
    
    diaContainer.insertAdjacentHTML('beforeend', loaderHTML);

    fetch(`/planificacion/generar_observacion_dia/${diaId}/`, {
        method: 'POST',
        headers: {
            'X-CSRFToken': getCookie('csrftoken')
        }
    })
    .then(response => response.json())
    .then(data => {
        // Remover el loader
        const loader = document.querySelector('.temp-loader');
        if (loader) {
            loader.remove();
        }

        if (data.observacion) {
            // Remover observación existente si hay
            const observacionExistente = diaContainer.querySelector('.bg-green-50');
            if (observacionExistente) {
                observacionExistente.remove();
            }

            // Insertar nueva observación antes del botón
            const botonObservacion = diaContainer.querySelector('.btn-generar-observacion-dia');
            botonObservacion.insertAdjacentHTML('beforebegin', mostrarObservacionDia(data.observacion));
        }
    })
    .catch(error => {
        // Remover el loader en caso de error
        const loader = document.querySelector('.temp-loader');
        if (loader) {
            loader.remove();
        }
        
        console.error('Error:', error);
        alert('Error al generar la observación del día');
    });
}

document.addEventListener('DOMContentLoaded', function() {
    const diasCheckboxes = document.querySelectorAll('input[name="dias_semana"]');
    const diasClasesInput = document.querySelector('input[name="dias_clases"]');
    const diasError = document.getElementById('dias-error');
    
    diasCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            const checkedDays = document.querySelectorAll('input[name="dias_semana"]:checked').length;
            const requiredDays = parseInt(diasClasesInput.value) || 0;
            
            if (checkedDays > requiredDays) {
                this.checked = false;
                diasError.textContent = `Solo puede seleccionar ${requiredDays} días`;
                diasError.classList.remove('hidden');
            } else if (checkedDays === requiredDays) {
                diasError.classList.add('hidden');
            } else {
                diasError.textContent = `Debe seleccionar ${requiredDays} días`;
                diasError.classList.remove('hidden');
            }
        });
    });
    
    diasClasesInput.addEventListener('change', function() {
        const checkedDays = document.querySelectorAll('input[name="dias_semana"]:checked');
        checkedDays.forEach(checkbox => checkbox.checked = false);
        diasError.classList.add('hidden');
    });
});

function mostrarDiaSeleccionado(dia) {
    const contenedor = document.getElementById('diaSeleccionado');
    
    // Función para limpiar texto de asteriscos y guiones
    const limpiarTexto = (texto) => {
        return texto
            .replace(/\*{4,}/g, '')
            .replace(/^- /, '')
            .trim();
    };

    contenedor.innerHTML = `
        <div class="bg-white rounded-xl p-6 border-2 border-purple-100 shadow-lg mb-6 hover:shadow-xl transition-shadow">
            <!-- Encabezado del día con fecha y estado de feriado -->
            <div class="bg-purple-50 rounded-xl p-4 mb-6 border-2 border-purple-200">
                <div class="flex items-center justify-between">
                    <h4 class="text-xl font-bold text-purple-900 flex items-center">
                        <i class="ph ph-calendar-check text-2xl text-purple-600 mr-3"></i>
                        Semana ${dia.semana} - Día ${dia.dia}
                    </h4>
                    <div class="flex items-center space-x-2">
                        ${dia.fecha ? `
                            <span class="px-3 py-1 rounded-full bg-purple-100 text-purple-700 text-sm">
                                ${dia.fecha}
                            </span>
                        ` : ''}
                        ${dia.es_feriado ? `
                            <span class="px-3 py-1 rounded-full bg-red-100 text-red-700 text-sm flex items-center">
                                <i class="ph ph-warning-circle mr-1"></i>
                                Feriado
                            </span>
                        ` : ''}
                    </div>
                </div>
            </div>
            
            <!-- Sección Contenido -->
            <div class="bg-white rounded-xl p-6 border-2 border-purple-100 shadow-sm hover:shadow-md transition-shadow mb-6">
                <h3 class="text-xl font-bold text-purple-900 mb-4 flex items-center">
                    <i class="ph ph-book-open text-2xl text-purple-600 mr-3"></i>
                    Contenido
                </h3>
                <p class="text-gray-700 text-lg pl-9">${limpiarTexto(dia.contenido)}</p>
            </div>
            
            <!-- Sección Resumen -->
            <div class="bg-white rounded-xl p-6 border-2 border-purple-100 shadow-sm hover:shadow-md transition-shadow mb-6">
                <h3 class="text-xl font-bold text-purple-900 mb-4 flex items-center">
                    <i class="ph ph-clipboard-text text-2xl text-purple-600 mr-3"></i>
                    Resumen
                </h3>
                <p class="text-gray-700 text-lg pl-9">${limpiarTexto(dia.resumen)}</p>
            </div>
            
            <!-- Sección Actividad -->
            <div class="bg-white rounded-xl p-6 border-2 border-purple-100 shadow-sm hover:shadow-md transition-shadow mb-6">
                <h3 class="text-xl font-bold text-purple-900 mb-4 flex items-center">
                    <i class="ph ph-target text-2xl text-purple-600 mr-3"></i>
                    Actividad
                </h3>
                <p class="text-gray-700 text-lg pl-9">${limpiarTexto(dia.actividad)}</p>
            </div>
            
            <!-- Sección Objetivos de Aprendizaje -->
            <div class="bg-white rounded-xl p-6 border-2 border-purple-100 shadow-sm hover:shadow-md transition-shadow mb-6">
                <h3 class="text-xl font-bold text-purple-900 mb-4 flex items-center">
                    <i class="ph ph-target text-2xl text-purple-600 mr-3"></i>
                    Objetivos de Aprendizaje
                </h3>
                <div class="text-gray-700 text-lg pl-9">
                    ${dia.objetivos.split('\n')
                        .map(objetivo => objetivo.trim())
                        .filter(objetivo => objetivo && objetivo.length > 1)
                        .map(objetivo => 
                            `<p class="mb-2">${limpiarTexto(objetivo)}</p>`
                        ).join('')}
                </div>
            </div>

            <!-- Sección Comentarios -->
            <div class="bg-purple-50 rounded-xl p-8 border-2 border-purple-200 shadow-lg mb-6">
                <div class="flex items-center mb-6">
                    <div class="bg-purple-200 rounded-full p-3">
                        <i class="ph ph-chat-circle-text text-purple-700 text-3xl"></i>
                    </div>
                    <div class="ml-4">
                        <h3 class="text-xl font-bold text-purple-900">Comentarios y Notas</h3>
                        <p class="text-purple-600 mt-1">Registra tus observaciones sobre esta clase</p>
                    </div>
                </div>
                
                <div class="bg-white rounded-xl p-6 shadow-md">
                    <textarea
                        class="w-full p-4 text-gray-700 bg-gray-50 border-2 border-purple-200 rounded-xl
                               focus:ring-4 focus:ring-purple-500 focus:border-purple-500
                               min-h-[150px] text-lg placeholder-gray-500 resize-y comentario-input mb-4"
                        placeholder="Escribe aquí tus notas y comentarios sobre la clase..."
                        data-dia-id="${dia.id}"
                    >${dia.comentario || ''}</textarea>
                    
                    <div class="flex items-center space-x-4">
                        <button 
                            class="btn-guardar-comentario inline-flex items-center px-6 py-3 
                                   bg-purple-600 text-white rounded-xl hover:bg-purple-700 
                                   transition-all transform hover:scale-105 hover:shadow-lg 
                                   active:scale-95 text-lg font-medium"
                            data-dia-id="${dia.id}"
                        >
                            <i class="ph ph-check-circle text-xl mr-2"></i>
                            Guardar Comentario
                        </button>
                        <span class="mensaje-guardado hidden text-green-600 font-medium flex items-center">
                            <i class="ph ph-check-circle text-xl mr-2"></i>
                            Comentario guardado
                        </span>
                    </div>
                </div>
            </div>

            <!-- Sección Observación AI -->
            <div class="bg-emerald-50 rounded-xl p-8 border-2 border-emerald-200 shadow-lg">
                <div class="flex items-center mb-6">
                    <div class="bg-emerald-200 rounded-full p-3">
                        <i class="ph ph-sparkle text-emerald-700 text-3xl"></i>
                    </div>
                    <div class="ml-4">
                        <h3 class="text-xl font-bold text-emerald-900">Observación IA</h3>
                        <p class="text-emerald-600 mt-1">Análisis y sugerencias generadas por IA</p>
                    </div>
                </div>

                ${dia.observacion ? `
                    <div class="bg-white rounded-xl p-6 shadow-md mb-4">
                        <div class="text-gray-700 space-y-3 prose prose-emerald max-w-none">
                            ${dia.observacion.split('\n').map(parrafo => `<p>${parrafo}</p>`).join('')}
                        </div>
                    </div>
                ` : ''}

                <button 
                    class="btn-generar-observacion-dia inline-flex items-center px-6 py-3 
                           bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 
                           transition-all transform hover:scale-105 hover:shadow-lg 
                           active:scale-95 text-lg font-medium"
                    data-dia-id="${dia.id}"
                >
                    <i class="ph ph-robot text-xl mr-2"></i>
                    ${dia.observacion ? 'Regenerar Observación' : 'Generar Observación'}
                </button>
            </div>
        </div>
    `;

    // Agregar event listeners para los botones
    const botonGuardar = contenedor.querySelector('.btn-guardar-comentario');
    if (botonGuardar) {
        botonGuardar.addEventListener('click', function() {
            const textarea = this.parentElement.parentElement.querySelector('textarea');
            const mensajeGuardado = this.nextElementSibling;
            guardarComentario(dia.id, textarea.value, mensajeGuardado, true);
        });
    }

    const botonObservacion = contenedor.querySelector('.btn-generar-observacion-dia');
    if (botonObservacion) {
        botonObservacion.addEventListener('click', function() {
            generarObservacionDia(dia.id);
        });
    }
}


function actualizarSelectorDias(data) {
    const selectorContainer = document.createElement('div');
    selectorContainer.className = 'selector-dias mb-4';
    selectorContainer.innerHTML = `
        <label class="form-label">Seleccionar día:</label>
        <select class="form-select" id="selectDia">
            <option value="">Seleccione un día</option>
            ${data.dias.map(dia => {
                const esFeriado = dia.es_feriado ? '🔴 Feriado' : '';
                const fecha = dia.fecha ? ` (${dia.fecha})` : '';
                const comentado = dia.comentario ? '✓' : '';
                return `
                    <option value="${dia.id}" 
                            data-comentado="${dia.comentario ? 'true' : 'false'}"
                            class="${dia.es_feriado ? 'text-red-600' : ''}">
                        Semana ${dia.semana} - Día ${dia.dia}${fecha} ${esFeriado} ${comentado}
                    </option>
                `;
            }).join('')}
        </select>
    `;
    return selectorContainer;
}