// Función para obtener el token CSRF de las cookies
// Función para obtener el token CSRF de las cookies
function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let cookie of cookies) {
            cookie = cookie.trim();
            if (cookie.startsWith(name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

const csrftoken = getCookie('csrftoken');

document.getElementById('planningForm').onsubmit = function(event) {
    event.preventDefault();
    document.getElementById('loadingIcon').style.display = 'block';
    document.getElementById('generatedPlans').style.display = 'none';

    var formData = new FormData(this);

    fetch("IA_app/generate_plan/", {
        method: 'POST',
        body: formData,
        headers: {
            'X-CSRFToken': csrftoken
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`Error en la respuesta del servidor: ${response.status} ${response.statusText}`);
        }
        return response.json();
    })
    .then(data => {
        document.getElementById('loadingIcon').style.display = 'none';

        if (data.plan) {
            document.getElementById('plansContent').innerHTML = `
                <div class="plan">
                    ${data.plan}
                </div>
            `;
            document.getElementById('generatedPlans').style.display = 'block';

            // Mostrar el botón de descarga PDF
            const downloadButton = document.getElementById('downloadButton');
            downloadButton.href = `IA_app/descargar_plan_pdf/${data.plan_id}/`;
            downloadButton.style.display = 'block';
        } else if (data.error) {
            alert("Error: " + data.error);
        }
    })
    .catch(error => {
        document.getElementById('loadingIcon').style.display = 'none';
        alert("Hubo un error: " + error.message);
    });
};

// Lógica para prevalidar y filtrar materias basado en el curso seleccionado
document.getElementById('curso').addEventListener('change', function() {
    var selectedCurso = this.value;
    var materias = document.querySelectorAll('#materia option');

    materias.forEach(function(materia) {
        if (materia.getAttribute('data-curso') === selectedCurso || materia.value === "") {
            materia.style.display = 'block';
        } else {
            materia.style.display = 'none';
        }
    });

    document.getElementById('materia').value = "";
});

// Función para redirigir al usuario a la página de visualización de planes
document.getElementById('viewPlansButton').addEventListener('click', function() {
    window.location.href = "IA_app/ver_planes/";
});