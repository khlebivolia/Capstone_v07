from django.db import models

class Planificacion(models.Model):
    materia = models.CharField(max_length=100)
    curso = models.CharField(max_length=100)
    periodo = models.CharField(max_length=50)
    dias_clases = models.IntegerField()
    descripcion = models.TextField()
    contenido = models.TextField()  # Aquí se guarda el plan generado
    creado_el = models.DateTimeField(auto_now_add=True)
