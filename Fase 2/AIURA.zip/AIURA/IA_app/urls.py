from django.urls import path
from . import views

urlpatterns = [
    path('IA_app', views.index, name='index'),
    path('generate_plan/', views.generate_plan, name='generate_plan'),
    path('descargar_plan_pdf/<int:plan_id>/', views.descargar_plan_pdf, name='descargar_plan_pdf'),
    path('ver_planes/', views.ver_planes, name='ver_planes'),
]
