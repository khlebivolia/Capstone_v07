# # from django.shortcuts import render, get_object_or_404
# # from django.http import JsonResponse, HttpResponse
# # from django.conf import settings
# # import os
# # from langchain.chat_models import ChatOpenAI
# # from langchain.document_loaders import PyPDFLoader
# # from langchain.vectorstores import FAISS
# # from langchain.embeddings import OpenAIEmbeddings
# from langchain.chains import RetrievalQA
# from openai.error import OpenAIError
# import tiktoken
# import threading
# from .models import Planificacion
# from django.template.loader import render_to_string
# from xhtml2pdf import pisa
# from weasyprint import HTML
from langchain.schema import Document
from django.shortcuts import render, get_object_or_404
from django.http import JsonResponse, HttpResponse
from django.conf import settings
import os
from langchain.chat_models import ChatOpenAI
from langchain.document_loaders import PyPDFLoader
from langchain.vectorstores import FAISS
from langchain.embeddings import OpenAIEmbeddings
from langchain.chains import RetrievalQA
from openai.error import OpenAIError
import tiktoken
import threading
from .models import Planificacion
from django.template.loader import render_to_string
from xhtml2pdf import pisa
from django.urls import path
from io import BytesIO

# Variable global para almacenar el vectorstore
vectorstore = None
vectorstore_lock = threading.Lock()

def count_tokens(text, model_name="gpt-4o-mini"):
    encoding = tiktoken.encoding_for_model(model_name)
    return len(encoding.encode(text))

def load_or_create_vectorstore(curso, materia):
    global vectorstore
    with vectorstore_lock:
        vectorstore_name = f"{curso}_{materia}_vectorstore"
        vectorstore_path = os.path.join(settings.BASE_DIR, 'faiss_index', vectorstore_name)

        if vectorstore is None or not os.path.exists(os.path.join(vectorstore_path, "index.faiss")):
            print(f"Cargando o creando el vectorstore para {curso} - {materia}...")

            try:
                pdf_folder = os.path.join(settings.BASE_DIR, 'IA_app', 'static', 'PDF', curso, materia)
                documents = []

                if not os.path.exists(pdf_folder):
                    print(f'La carpeta de PDFs para {curso} - {materia} no existe.')
                    return None

                for filename in os.listdir(pdf_folder):
                    if filename.endswith(".pdf"):
                        pdf_path = os.path.join(pdf_folder, filename)
                        loader = PyPDFLoader(pdf_path)
                        pages = loader.load()
                        full_text = "\n".join([page.page_content for page in pages])
                        document = Document(page_content=full_text, metadata={"filename": filename})
                        documents.append(document)

                embeddings = OpenAIEmbeddings(openai_api_key=settings.OPENAI_API_KEY)
                vectorstore = FAISS.from_documents(documents, embeddings)
                os.makedirs(vectorstore_path, exist_ok=True)
                vectorstore.save_local(vectorstore_path)
                print(f"El vectorstore para {curso} - {materia} se creó y guardó correctamente.")

            except Exception as e:
                import traceback
                traceback.print_exc()
                print(f'Error al cargar o crear el vectorstore: {e}')
                vectorstore = None
        else:
            print(f"El vectorstore para {curso} - {materia} ya está cargado desde disco.")
    
    return vectorstore

def index(request):
    return render(request, 'planning.html')

def format_generated_plan(plan):
    formatted_plan = plan.replace("###", "<h4>").replace("####", "<h5>").replace("**", "<strong>").replace("\n", "<br>")
    return formatted_plan

def generate_plan(request):
    if request.method == 'POST':
        materia = request.POST.get('materia')
        periodo = request.POST.get('periodo')
        dias_clases = request.POST.get('dias_clases')
        curso = request.POST.get('curso')
        descripcion = request.POST.get('descripcion')

        if not all([materia, periodo, dias_clases, curso]):
            return JsonResponse({'error': 'Todos los campos son obligatorios.'})

        vs = load_or_create_vectorstore(curso, materia)
        if vs is None:
            return JsonResponse({'error': 'No se pudo cargar o crear el vectorstore.'})

        prompt = (f"""
        Genera un plan de clases para la materia **{materia}**, curso **{curso}**, durante un **{periodo}**.

        El plan debe contemplar **{dias_clases} días de clases a la semana**. Para **cada día de clase**, necesito:

        - Un tema del contenido
        - Un resumen
        - Una actividad
        - Una lectura recomendada

        **Descripción adicional:** {descripcion}

        ---
        ### Plan de Clases de {materia} - {curso} ({periodo})
        
        #### Semana X
        
        **Día 1:**
        - **Contenido:**
        - **Resumen:**
        - **Actividad:**
        - **Lectura Recomendada:**

        *(Repetir hasta completar {dias_clases} días por semana)*
        ---
        """)

        prompt_tokens = count_tokens(prompt)
        max_allowed_tokens = 4096 - prompt_tokens
        if max_allowed_tokens <= 0:
            return JsonResponse({'error': 'El prompt es demasiado largo. Por favor, reduce su tamaño.'})

        max_tokens = min(750, max_allowed_tokens)

        try:
            llm = ChatOpenAI(
                openai_api_key=settings.OPENAI_API_KEY,
                model_name='gpt-4o-mini',
                temperature=0,
            )

            retriever = vs.as_retriever()
            qa_chain = RetrievalQA.from_chain_type(
                llm=llm,
                chain_type="stuff",
                retriever=retriever
            )

            generated_plan = qa_chain.run(prompt)

            if isinstance(generated_plan, str) and generated_plan.strip() != "":
                nuevo_plan = Planificacion.objects.create(
                    materia=materia,
                    curso=curso,
                    periodo=periodo,
                    dias_clases=dias_clases,
                    descripcion=descripcion,
                    contenido=generated_plan
                )
                return JsonResponse({'plan': format_generated_plan(generated_plan), 'plan_id': nuevo_plan.id})
            else:
                return JsonResponse({'error': 'El plan generado no es válido o está vacío.'})

        except OpenAIError as e:
            return JsonResponse({'error': f'Error en la API de OpenAI: {str(e)}'})
        except Exception as e:
            return JsonResponse({'error': f'Error inesperado: {str(e)}'})

    return render(request, 'planning.html')

def descargar_plan_pdf(request, plan_id):
    plan = get_object_or_404(Planificacion, id=plan_id)
    formatted_contenido = format_generated_plan(plan.contenido)
    html_string = render_to_string('pdf_template.html', {'plan': plan, 'formatted_contenido': formatted_contenido})

    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="Plan_{plan.curso}_{plan.materia}.pdf"'
    result = BytesIO()
    pisa_status = pisa.CreatePDF(BytesIO(html_string.encode('utf-8')), dest=result)
    if pisa_status.err:
        return HttpResponse('Error al generar el PDF', status=500)
    response.write(result.getvalue())
    return response

def ver_planes(request):
    planes = Planificacion.objects.all()
    return render(request, 'ver_planes.html', {'planes': planes})