// // Actions:

// const closeButton = `<svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32">
// <title>remove</title>
// <path d="M27.314 6.019l-1.333-1.333-9.98 9.981-9.981-9.981-1.333 1.333 9.981 9.981-9.981 9.98 1.333 1.333 9.981-9.98 9.98 9.98 1.333-1.333-9.98-9.98 9.98-9.981z"></path>
// </svg>
// `;
// const menuButton = `<svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32">
// <title>ellipsis-horizontal</title>
// <path d="M16 7.843c-2.156 0-3.908-1.753-3.908-3.908s1.753-3.908 3.908-3.908c2.156 0 3.908 1.753 3.908 3.908s-1.753 3.908-3.908 3.908zM16 1.98c-1.077 0-1.954 0.877-1.954 1.954s0.877 1.954 1.954 1.954c1.077 0 1.954-0.877 1.954-1.954s-0.877-1.954-1.954-1.954z"></path>
// <path d="M16 19.908c-2.156 0-3.908-1.753-3.908-3.908s1.753-3.908 3.908-3.908c2.156 0 3.908 1.753 3.908 3.908s-1.753 3.908-3.908 3.908zM16 14.046c-1.077 0-1.954 0.877-1.954 1.954s0.877 1.954 1.954 1.954c1.077 0 1.954-0.877 1.954-1.954s-0.877-1.954-1.954-1.954z"></path>
// <path d="M16 31.974c-2.156 0-3.908-1.753-3.908-3.908s1.753-3.908 3.908-3.908c2.156 0 3.908 1.753 3.908 3.908s-1.753 3.908-3.908 3.908zM16 26.111c-1.077 0-1.954 0.877-1.954 1.954s0.877 1.954 1.954 1.954c1.077 0 1.954-0.877 1.954-1.954s-0.877-1.954-1.954-1.954z"></path>
// </svg>
// `;

// const actionButtons = document.querySelectorAll('.action-button');

// if (actionButtons) {
//   actionButtons.forEach(button => {
//     button.addEventListener('click', () => {
//       const buttonId = button.dataset.id;
//       let popup = document.querySelector(`.popup-${buttonId}`);
//       console.log(popup);
//       if (popup) {
//         button.innerHTML = menuButton;
//         return popup.remove();
//       }

//       const deleteUrl = button.dataset.deleteUrl;
//       const editUrl = button.dataset.editUrl;
//       button.innerHTML = closeButton;

//       popup = document.createElement('div');
//       popup.classList.add('popup');
//       popup.classList.add(`popup-${buttonId}`);
//       popup.innerHTML = `<a href="${editUrl}">Edit</a>
//       <form action="${deleteUrl}" method="delete">
//         <button type="submit">Delete</button>
//       </form>`;
//       button.insertAdjacentElement('afterend', popup);
//     });
//   });
// }

// Menu

const dropdownMenu = document.querySelector(".dropdown-menu");
const dropdownButton = document.querySelector(".dropdown-button");

if (dropdownButton) {
  dropdownButton.addEventListener("click", () => {
    dropdownMenu.classList.toggle("show");
  });
}

// Upload Image
const photoInput = document.querySelector("#avatar");
const photoPreview = document.querySelector("#preview-avatar");
if (photoInput)
  photoInput.onchange = () => {
    const [file] = photoInput.files;
    if (file) {
      photoPreview.src = URL.createObjectURL(file);
    }
  };

// Scroll to Bottom
const conversationThread = document.querySelector(".room__box");
if (conversationThread) conversationThread.scrollTop = conversationThread.scrollHeight;

// Función para obtener el token CSRF de las cookies
function getCookie(name) {
  let cookieValue = null;
  if (document.cookie && document.cookie !== '') {
      const cookies = document.cookie.split(';');
      for (let cookie of cookies) {
          cookie = cookie.trim();
          // Comprueba si esta cookie comienza con el nombre que buscamos
          if (cookie.startsWith(name + '=')) {
              cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
              break;
          }
      }
  }
  return cookieValue;
}

const csrftoken = getCookie('csrftoken');

document.getElementById('planningForm').onsubmit = function(event) {
  event.preventDefault();  // Evita que el formulario se envíe de manera convencional.

  // Mostrar el ícono de carga
  document.getElementById('loadingIcon').style.display = 'block';

  // Ocultar los resultados previos, si existen
  document.getElementById('generatedPlans').style.display = 'none';

  var formData = new FormData(this);  // Captura los datos del formulario

  fetch("/generate_plan/", {
      method: 'POST',
      body: formData,
      headers: {
          'X-CSRFToken': csrftoken
      }
  })
  .then(response => {
      if (!response.ok) {
          throw new Error(`Error en la respuesta del servidor: ${response.status} ${response.statusText}`);
      }
      return response.json();
  })
  .then(data => {
      // Oculta el ícono de carga
      document.getElementById('loadingIcon').style.display = 'none';

      if (data.plan) {
          document.getElementById('plansContent').innerHTML += `
              <div class="plan">
                  ${data.plan}  <!-- Plan con formato HTML -->
              </div>
          `;
          document.getElementById('generatedPlans').style.display = 'block';

          // Actualizar el estado del botón
          const submitButton = document.getElementById('submitButton');
          if (data.period_count < data.total_periods) {
              submitButton.innerText = `Generar periodo ${data.period_count + 1}`;
          } else {
              submitButton.innerText = 'Planificación Completa';
              submitButton.disabled = true;
          }

      } else if (data.error) {
          alert("Error: " + data.error);  // Mostrar el mensaje de error si no hay un plan
      }
  })
  .catch(error => {
      document.getElementById('loadingIcon').style.display = 'none';
      alert("Hubo un error: " + error.message);
  });
};

// Lógica para prevalidar y filtrar materias basado en el curso seleccionado
document.getElementById('curso').addEventListener('change', function() {
  var selectedCurso = this.value;
  var materias = document.querySelectorAll('#materia option');

  // Mostrar las materias correspondientes al curso seleccionado
  materias.forEach(function(materia) {
      if (materia.getAttribute('data-curso') === selectedCurso || materia.value === "") {
          materia.style.display = 'block';  // Mostrar la materia si coincide el curso
      } else {
          materia.style.display = 'none';  // Ocultar si no corresponde al curso
      }
  });

  // Reiniciar el valor del select de materias
  document.getElementById('materia').value = "";
});
