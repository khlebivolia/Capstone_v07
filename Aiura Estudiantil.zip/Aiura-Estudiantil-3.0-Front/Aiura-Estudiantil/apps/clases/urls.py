from django.urls import path
from . import views

app_name = 'classroom'

urlpatterns = [
    path('dashboard/', views.dashboard, name='dashboard'),
    path('course/', views.lista_cursos, name='lista_cursos'),
    path('course/<int:course_id>/', views.notas_estudiantes, name='notas_estudiantes'),
    path('course/<int:course_id>/grades/<int:student_id>', views.actualizar_notas, name='actualizar_notas'),
    path('course/<int:course_id>/attendance/', views.pasar_asistencia, name='pasar_asistencia'),
    path('curso/<int:course_id>/ver-asistencias/', views.ver_asistencias, name='ver_asistencias'),
    path('course/<int:course_id>/detail/', views.detalle_curso, name='detalle_curso'),
]
