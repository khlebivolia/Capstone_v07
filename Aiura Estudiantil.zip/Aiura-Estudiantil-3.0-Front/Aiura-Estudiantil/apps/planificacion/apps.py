from django.apps import AppConfig

class PlanificacionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.planificacion'
    verbose_name = 'Planner'