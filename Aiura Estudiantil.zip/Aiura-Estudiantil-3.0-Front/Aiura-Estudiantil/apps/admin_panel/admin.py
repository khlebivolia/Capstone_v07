from django.contrib import admin
from .models import Profesor, Curso, Alumno, Asistencia, Nota

admin.site.register(Profesor)
admin.site.register(Curso)
admin.site.register(Alumno)
admin.site.register(Asistencia)
admin.site.register(Nota)
