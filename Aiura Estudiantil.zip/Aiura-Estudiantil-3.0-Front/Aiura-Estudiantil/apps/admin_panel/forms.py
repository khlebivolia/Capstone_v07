from django import forms
from django.contrib.auth.models import User

from .models import Alumno
from .models import Curso, Profesor


class TeacherForm(forms.ModelForm):
    username = forms.CharField(max_length=150)
    password = forms.CharField(widget=forms.PasswordInput, required=False)
    first_name = forms.CharField(max_length=150, label='Nombre')
    last_name = forms.CharField(max_length=150, label='Apellido')
    email = forms.EmailField(label='Correo')
    cursos = forms.ModelMultipleChoiceField(
        queryset=Curso.objects.all(),
        widget=forms.CheckboxSelectMultiple,
        required=False,
        label='Cursos'
    )

    class Meta:
        model = Profesor
        fields = ['materia', 'cursos']
        widgets = {
            'materia': forms.TextInput(attrs={'placeholder': 'Ingrese la materia que enseña'}),
        }

    def save(self, commit=True):
        teacher = super().save(commit=False)

        if not teacher.user_id:
            teacher.user = User()

        teacher.user.username = self.cleaned_data['username']
        teacher.user.first_name = self.cleaned_data['first_name']
        teacher.user.last_name = self.cleaned_data['last_name']
        teacher.user.email = self.cleaned_data['email']

        if self.cleaned_data['password']:
            teacher.user.set_password(self.cleaned_data['password'])

        if commit:
            teacher.user.save()
            teacher.save()

            self.save_m2m()

        return teacher

# Formulario para el modelo de Curso
class CourseForm(forms.ModelForm):
    profesores = forms.ModelMultipleChoiceField(
        queryset=Profesor.objects.all(),
        widget=forms.CheckboxSelectMultiple,
        required=False,
        label='Profesores'
    )

    class Meta:
        model = Curso
        fields = ['curso', 'profesores']
        widgets = {
            'curso': forms.TextInput(attrs={'placeholder': 'Ejemplo: Cuarto C o Cuarto E'}),
        }

    def save(self, commit=True):
        curso = super().save(commit=False)

        if commit:
            curso.save()

            if 'profesores' in self.cleaned_data:
                curso.profesores.set(self.cleaned_data['profesores'])

        return curso

# Formulario para el modelo de Alumno
class StudentForm(forms.ModelForm):
    class Meta:
        model = Alumno
        fields = ['nombre', 'apellido', 'curso']
        widgets = {
            'nombre': forms.TextInput(attrs={'placeholder': 'Nombre del alumno'}),
            'apellido': forms.TextInput(attrs={'placeholder': 'Apellido del alumno'}),
        }