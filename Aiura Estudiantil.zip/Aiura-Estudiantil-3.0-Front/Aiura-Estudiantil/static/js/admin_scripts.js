// static/js/admin_scripts.js

// Funciones generales
function showModal(modalId) {
    const modal = document.getElementById(modalId);
    modal.style.display = 'block';
}

function hideModal(modalId) {
    const modal = document.getElementById(modalId);
    modal.style.display = 'none';
}

function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}
// Exportación a Excel
function exportToExcel(tableId) {
    const table = document.getElementById(tableId);
    const wb = XLSX.utils.table_to_book(table, { sheet: "Sheet1" });
    XLSX.writeFile(wb, `export_${Date.now()}.xlsx`);
}
// Funciones para Profesores
function showAddTeacherModal() {
    const form = document.getElementById('teacherForm');
    form.reset();
    document.getElementById('modalTitle').textContent = 'Agregar Profesor';
    showModal('teacherModal');
}

function editTeacher(profesor_id) {
    fetch(`/admin_panel/teachers/${profesor_id}/edit/`)
        .then(response => {
            if (!response.ok) {
                throw new Error('La respuesta de la red no era correcta');
            }
            return response.json();
        })
        .then(data => {
            const form = document.getElementById('teacherForm');
            form.reset();

            // Actualizar la URL del formulario para enviar los datos correctamente
            form.action = `/admin_panel/teachers/${profesor_id}/edit/`;

            // Limpiar cualquier mensaje de error previo
            clearFormErrors(form);

            // Actualizar cada campo del formulario
            for (let field in data) {
                const inputs = form.querySelectorAll(`[name="${field}"]`);

                inputs.forEach(input => {
                    if (input.type === 'checkbox') {
                        if (Array.isArray(data[field])) {
                            input.checked = data[field].includes(parseInt(input.value));
                        } else {
                            input.checked = Boolean(data[field]);
                        }
                    } else {
                        input.value = data[field] || '';
                    }
                });
            }

            document.getElementById('modalTitle').textContent = 'Editar Profesor';
            showModal('teacherModal');

            // Agregar el evento submit para manejar el envío sin redirigir
            form.onsubmit = function(event) {
                event.preventDefault(); // Evita el envío tradicional del formulario

                // Limpiar mensajes de error previos
                clearFormErrors(form);

                const formData = new FormData(form);

                fetch(`/admin_panel/teachers/${profesor_id}/edit/`, {
                    method: 'POST',
                    headers: {
                        'X-CSRFToken': getCsrfToken() // Remueve 'Content-Type' para enviar FormData correctamente
                    },
                    body: formData
                })
                    .then(response => response.json())
                    .then(result => {
                        if (result.success) {
                            hideModal('teacherModal'); // Cierra el modal al completar la actualización
                            window.location.reload(); // Recarga la página
                        } else {
                            // Si hay errores, mostrarlos en el formulario
                            showFormErrors(form, result.errors);
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                    });
            };
        })
        .catch(error => {
            console.error('Error:', error);
        });
}
// Función para limpiar mensajes de error previos
function clearFormErrors(form) {
    const errorElements = form.querySelectorAll('.error-message');
    errorElements.forEach(element => element.remove());
}
// Función para mostrar mensajes de error en el formulario
function showFormErrors(form, errors) {
    for (let field in errors) {
        const input = form.querySelector(`[name="${field}"]`);
        if (input) {
            const errorMessage = document.createElement('div');
            errorMessage.className = 'error-message';
            errorMessage.style.color = 'red';
            errorMessage.textContent = errors[field].join(', '); // Unir los mensajes de error
            input.parentNode.appendChild(errorMessage);
        }
    }
}
// Función para obtener el token CSRF si estás usando Django con protección CSRF
function getCsrfToken() {
    const csrfToken = document.querySelector('[name=csrfmiddlewaretoken]');
    return csrfToken ? csrfToken.value : '';
}

function deleteTeacher(profesor_id) {
    if (confirm('estas seguro de eliminar ?' )) {
        const csrftoken = getCookie('csrftoken');
        fetch(`/admin_panel/teachers/${profesor_id}/delete/`, {
            method: 'POST',
            headers: { 'X-CSRFToken': csrftoken },
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) location.reload();
                else console.error(data.error || 'Error al eliminar');
            })
            .catch(error => {
                console.error('Error al borrar profesor:', error);
            });
    }
}
// Funciones para Cursos
function showAddCourseModal() {
    const form = document.getElementById('courseForm');
    form.reset();
    document.getElementById('modalTitle').textContent = 'Add Course';
    showModal('courseModal');
}

function editCourse(courseId) {
    fetch(`/admin_panel/courses/${courseId}/edit/`)
        .then(response => response.ok ? response.json() : Promise.reject('Failed to load'))
        .then(data => {
            const form = document.getElementById('courseForm');
            form.reset();

            // Limpiar cualquier mensaje de error previo
            clearFormErrors(form);

            // Actualizar cada campo del formulario
            for (let field in data) {
                const inputs = form.querySelectorAll(`[name="${field}"]`);

                inputs.forEach(input => {
                    if (input.type === 'checkbox') {
                        if (Array.isArray(data[field])) {
                            input.checked = data[field].includes(parseInt(input.value));
                        } else {
                            input.checked = Boolean(data[field]);
                        }
                    } else {
                        input.value = data[field] || '';
                    }
                });
            }

            document.getElementById('modalTitle').textContent = 'Edit Course';
            showModal('courseModal');

            // Agregar el evento submit para manejar el envío sin redirigir
            form.onsubmit = function(event) {
                event.preventDefault(); // Evita el envío tradicional del formulario

                // Limpiar mensajes de error previos
                clearFormErrors(form);

                const formData = new FormData(form);

                fetch(`/admin_panel/courses/${courseId}/edit/`, {
                    method: 'POST',
                    headers: {
                        'X-CSRFToken': getCsrfToken() // Remueve 'Content-Type' para enviar FormData correctamente
                    },
                    body: formData
                })
                    .then(response => response.json())
                    .then(result => {
                        if (result.success) {
                            hideModal('courseModal'); // Cierra el modal al completar la actualización
                            window.location.reload(); // Recarga la página
                        } else {
                            // Si hay errores, mostrarlos en el formulario
                            showFormErrors(form, result.errors);
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                    });
            };
        })
        .catch(error => {
            console.error('Error al cargar los datos del curso:', error);
        });
}

function deleteCourse(courseId) {
    if (confirm('Está seguro de que desea eliminar este curso?')) {
        const csrftoken = getCookie('csrftoken');
        fetch(`/admin_panel/courses/${courseId}/delete/`, {
            method: 'POST',
            headers: { 'X-CSRFToken': csrftoken },
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) location.reload();
                else console.error(data.error || 'Error al borrar un curso');
            })
            .catch(error => {
                console.error('Error al borrar un curso:', error);
            });
    }
}
// Funciones para Estudiantes
function showAddStudentModal() {
    const form = document.getElementById('studentForm');
    form.reset();
    document.getElementById('modalTitle').textContent = 'Añadir estudiante';
    showModal('studentModal');
}

function editStudent(alumno_id) {
    fetch(`/admin_panel/students/${alumno_id}/edit/`)
        .then(response => {
            if (!response.ok) {
                throw new Error('La respuesta de la red no era correcta');
            }
            return response.json();
        })
        .then(data => {
            const form = document.getElementById('studentForm');
            form.reset();

            // Actualizar la URL del formulario para enviar los datos correctamente
            form.action = `/admin_panel/students/${alumno_id}/edit/`;

            // Limpiar cualquier mensaje de error previo
            clearFormErrors(form);

            // Actualizar cada campo del formulario
            for (let field in data) {
                const inputs = form.querySelectorAll(`[name="${field}"]`);

                inputs.forEach(input => {
                    if (input.type === 'checkbox') {
                        if (Array.isArray(data[field])) {
                            input.checked = data[field].includes(parseInt(input.value));
                        } else {
                            input.checked = Boolean(data[field]);
                        }
                    } else {
                        input.value = data[field] || '';
                    }
                });
            }

            document.getElementById('modalTitle').textContent = 'Editar Estudiante';
            showModal('studentModal');

            // Agregar el evento submit para manejar el envío sin redirigir
            form.onsubmit = function(event) {
                event.preventDefault(); // Evita el envío tradicional del formulario

                // Limpiar mensajes de error previos
                clearFormErrors(form);

                const formData = new FormData(form);

                fetch(`/admin_panel/students/${alumno_id}/edit/`, {
                    method: 'POST',
                    headers: {
                        'X-CSRFToken': getCsrfToken() // Remueve 'Content-Type' para enviar FormData correctamente
                    },
                    body: formData
                })
                    .then(response => response.json())
                    .then(result => {
                        if (result.success) {
                            hideModal('studentModal'); // Cierra el modal al completar la actualización
                            window.location.reload(); // Recarga la página
                        } else {
                            // Si hay errores, mostrarlos en el formulario
                            showFormErrors(form, result.errors);
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                    });
            };
        })
        .catch(error => {
            console.error('Error:', error);
        });
}

function deleteStudent(alumno_id) {
    if (confirm('Estás seguro de que quieres borrar a este estudiante?')) {
        const csrftoken = getCookie('csrftoken');
        fetch(`/admin_panel/students/${alumno_id}/delete/`, {
            method: 'POST',
            headers: { 'X-CSRFToken': csrftoken },
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) location.reload();
                else console.error(data.error || 'Error al borrar un estudiante');
            })
            .catch(error => {
                console.error('Error al borrar un estudiante:', error);
            });
    }
}
// Event Listeners
document.addEventListener('DOMContentLoaded', function() {
    const closeButtons = document.getElementsByClassName('close');
    for (let button of closeButtons) {
        button.onclick = function() {
            hideModal(button.closest('.modal').id);
        }
    }

    window.onclick = function(event) {
        if (event.target.classList.contains('modal')) {
            hideModal(event.target.id);
        }
    }
});
