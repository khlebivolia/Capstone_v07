// Función para obtener el token CSRF de las cookies
function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let cookie of cookies) {
            cookie = cookie.trim();
            if (cookie.startsWith(name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

const csrftoken = getCookie('csrftoken');

let planIdAEliminar = null;
// Event Listener principal para cuando el DOM está cargado
document.addEventListener('DOMContentLoaded', function() {
    // Manejador para el botón de ver detalles
    const botonesVerDetalles = document.querySelectorAll('.btn-ver-detalles');
    botonesVerDetalles.forEach(boton => {
        boton.addEventListener('click', function() {
            const planId = this.dataset.planId;
            cargarDetallesPlan(planId);
        });
    });

    // Manejador para el botón de generar observación
    const botonObservacion = document.querySelector('.btn-generar-observacion');
    if (botonObservacion) {
        botonObservacion.addEventListener('click', function() {
            const planId = this.dataset.planId;
            generarObservacion(planId);
        });
    }

    // Event listeners para los botones de eliminar
    const botonesEliminar = document.querySelectorAll('.btn-eliminar');
    botonesEliminar.forEach(boton => {
        boton.addEventListener('click', function() {
            const planId = this.dataset.planId;
            confirmarEliminar(planId);
        });
    });

    // Event listener para el botón de continuar generando
    const continueButton = document.getElementById('continueButton');
    if (continueButton) {
        continueButton.addEventListener('click', () => generarPlan(true));
    }

    // Event listener para el botón de guardar
    const saveButton = document.getElementById('saveButton');
    if (saveButton) {
        saveButton.addEventListener('click', guardarPlan);
    }

    // Inicializar manejadores de eventos para los comentarios
    const comentariosInputs = document.querySelectorAll('.comentario-input');
    comentariosInputs.forEach(input => {
        input.addEventListener('change', manejarCambioComentario);
    });

    // Event listeners para el modal de eliminación
    const btnCancelarEliminar = document.getElementById('btnCancelarEliminar');
    const btnConfirmarEliminar = document.getElementById('btnConfirmarEliminar');
    
    if (btnCancelarEliminar) {
        btnCancelarEliminar.addEventListener('click', cerrarModal);
    }
    
    if (btnConfirmarEliminar) {
        btnConfirmarEliminar.addEventListener('click', function() {
            if (planIdAEliminar) {
                eliminarPlan(planIdAEliminar);
            }
        });
    }
});

// Función principal para generar el plan
document.getElementById('planningForm').onsubmit = function(event) {
    event.preventDefault();
    generarPlan(false);
};

// Funciones para eliminar planificación
function confirmarEliminar(planId) {
    planIdAEliminar = planId;
    document.getElementById('modalConfirmacion').classList.remove('hidden');
}

function cerrarModal() {
    document.getElementById('modalConfirmacion').classList.add('hidden');
    planIdAEliminar = null;
}

function eliminarPlan(planId) {
    fetch(`/planificacion/eliminar_plan/${planId}/`, {
        method: 'POST',
        headers: {
            'X-CSRFToken': csrftoken,
            'Content-Type': 'application/json'
        },
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Remover la tarjeta del plan eliminado
            const planCard = document.querySelector(`[data-plan-id="${planId}"]`).closest('.bg-white');
            planCard.remove();
            
            // Cerrar el modal
            cerrarModal();
            
            // Verificar si no quedan planes
            const planesRestantes = document.querySelectorAll('.bg-white').length;
            if (planesRestantes === 0) {
                location.reload(); // Recargar para mostrar el mensaje de "No tienes planificaciones"
            }
        } else {
            throw new Error(data.error || 'Error al eliminar el plan');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error al eliminar el plan: ' + error.message);
        cerrarModal();
    });
}

// Función mejorada para generar planes
function generarPlan(continueGeneration = false) {
    const loadingIcon = document.getElementById('loadingIcon');
    const generatedPlans = document.getElementById('generatedPlans');
    
    loadingIcon.style.display = 'block';

    const formData = new FormData(document.getElementById('planningForm'));
    formData.append('continue_generation', continueGeneration);

    fetch("/planificacion/generate_plan/", {
        method: 'POST',
        body: formData,
        headers: {
            'X-CSRFToken': csrftoken
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`Error en la respuesta del servidor: ${response.status} ${response.statusText}`);
        }
        return response.json();
    })
    .then(data => {
        loadingIcon.style.display = 'none';

        if (data.plan) {
            const plansContent = document.getElementById('plansContent');
            
            // Si es continuación, agregamos al contenido existente
            if (continueGeneration) {
                plansContent.innerHTML += `
                    <div class="mt-4 border-t pt-4">
                        ${data.plan}
                    </div>
                `;
            } else {
                plansContent.innerHTML = `
                    <div>
                        ${data.plan}
                    </div>
                `;
            }
            
            generatedPlans.style.display = 'block';
            
            // Mostrar botones de acciones
            const btnContainer = document.getElementById('btnContainer');
            btnContainer.style.display = 'flex';
            document.getElementById('continueButton').style.display = 'block';
            document.getElementById('saveButton').style.display = 'block';
            
            // Hacer scroll al final si es continuación
            if (continueGeneration) {
                plansContent.scrollTop = plansContent.scrollHeight;
            }
        } else if (data.error) {
            alert("Error: " + data.error);
        }
    })
    .catch(error => {
        loadingIcon.style.display = 'none';
        alert("Hubo un error: " + error.message);
    });
}
// Nueva función para guardar el plan
function guardarPlan() {
    fetch("/planificacion/guardar_plan/", {
        method: 'POST',
        headers: {
            'X-CSRFToken': csrftoken,
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Plan guardado exitosamente');
            // Limpiar la interfaz después de guardar
            document.getElementById('plansContent').innerHTML = '';
            document.getElementById('btnContainer').style.display = 'none';
            // Opcional: redireccionar a la página de ver planes
            // window.location.href = '/planificacion/ver_planes/';
        } else {
            throw new Error(data.error || 'Error al guardar el plan');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error al guardar el plan: ' + error.message);
    });
}
// Lógica para prevalidar y filtrar materias basado en el curso seleccionado
document.getElementById('curso').addEventListener('change', function() {
    var selectedCurso = this.value;
    var materias = document.querySelectorAll('#materia option');

    materias.forEach(function(materia) {
        if (materia.getAttribute('data-curso') === selectedCurso || materia.value === "") {
            materia.style.display = 'block';
        } else {
            materia.style.display = 'none';
        }
    });

    document.getElementById('materia').value = "";
});
// Función para redirigir al usuario a la página de visualización de planes
document.getElementById('viewPlansButton').addEventListener('click', function() {
    window.location.href = "/planificacion/ver_planes/";
});
// Función para cargar los detalles de un plan específico
function cargarDetallesPlan(planId) {
    const contenedor = document.getElementById('detallesPlan');
    if (!contenedor) return;
    
    contenedor.style.display = 'block';
    contenedor.innerHTML = '<div class="text-center"><div class="loader"></div><p>Cargando detalles...</p></div>';
    
    fetch(`/planificacion/ver_plan/${planId}/`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al cargar los detalles del plan');
            }
            return response.json();
        })
        .then(data => {
            contenedor.innerHTML = '';

            // Crear selector de días
            const selectorContainer = document.createElement('div');
            selectorContainer.className = 'selector-dias mb-4';
            selectorContainer.innerHTML = `
                <label class="form-label">Seleccionar día:</label>
                <select class="form-select" id="selectDia">
                    <option value="">Seleccione un día</option>
                    ${data.dias.map(dia => `
                        <option value="${dia.id}" data-comentado="${dia.comentario ? 'true' : 'false'}">
                            Semana ${dia.semana} - Día ${dia.dia}
                            ${dia.comentario ? '✓' : ''}
                        </option>
                    `).join('')}
                </select>
            `;
            contenedor.appendChild(selectorContainer);

            // Contenedor para el día seleccionado
            const diaContainer = document.createElement('div');
            diaContainer.id = 'diaSeleccionado';
            contenedor.appendChild(diaContainer);

            // Contenedor para el botón de observación
            const observacionContainer = document.createElement('div');
            observacionContainer.id = 'observacionContainer';
            observacionContainer.className = 'mt-4';
            contenedor.appendChild(observacionContainer);

            // Event listener para el selector
            const selector = contenedor.querySelector('#selectDia');
            selector.addEventListener('change', function() {
                const diaId = this.value;
                if (diaId) {
                    const diaSeleccionado = data.dias.find(d => d.id.toString() === diaId);
                    mostrarDiaSeleccionado(diaSeleccionado);
                } else {
                    document.getElementById('diaSeleccionado').innerHTML = '';
                }
                actualizarEstadoObservacion(selector, planId);
            });

            // Mostrar observación existente si hay
            if (data.observacion) {
                mostrarObservacion(data.observacion);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            contenedor.innerHTML = `
                <div class="alert alert-danger">
                    Error al cargar los detalles del plan. Por favor, intente nuevamente.
                </div>
            `;
        });
}

function mostrarDiaSeleccionado(dia) {
    const contenedor = document.getElementById('diaSeleccionado');
    
    // Función para limpiar texto de asteriscos y guiones
    const limpiarTexto = (texto) => {
        return texto
            .replace(/\*{4,}/g, '')  // Elimina los asteriscos
            .replace(/^- /, '')      // Elimina el guión inicial
            .trim();                 // Elimina espacios extras
    };

    contenedor.innerHTML = `
        <div class="dia-plan mb-4 p-4 border rounded">
            <div class="dia-titulo bg-primary text-white p-3 rounded-top mb-3">
                <h4 class="mb-0">Semana ${dia.semana} - Día ${dia.dia}</h4>
            </div>
            
            <div class="seccion-contenido mb-3">
                <div class="seccion-titulo border-bottom border-primary pb-2 mb-2">
                    <strong>Contenido:</strong>
                </div>
                <p class="pl-3">${limpiarTexto(dia.contenido)}</p>
            </div>
            
            <div class="seccion-contenido mb-3">
                <div class="seccion-titulo border-bottom border-primary pb-2 mb-2">
                    <strong>Resumen:</strong>
                </div>
                <p class="pl-3">${limpiarTexto(dia.resumen)}</p>
            </div>
            
            <div class="seccion-contenido mb-3">
                <div class="seccion-titulo border-bottom border-primary pb-2 mb-2">
                    <strong>Actividad:</strong>
                </div>
                <p class="pl-3">${limpiarTexto(dia.actividad)}</p>
            </div>
            
            <div class="seccion-contenido mb-3">
                <div class="seccion-titulo border-bottom border-primary pb-2 mb-2">
                    <strong>Lectura Recomendada:</strong>
                </div>
                <p class="pl-3">${limpiarTexto(dia.lectura)}</p>
            </div>

            <div class="seccion-comentario mt-4">
                <div class="comentario-container bg-light p-3 rounded">
                    <textarea
                        class="form-control comentario-input mb-2"
                        placeholder="Agregar comentario"
                        data-dia-id="${dia.id}"
                    >${dia.comentario || ''}</textarea>
                    <div class="button-container mt-2">
                        <button 
                            class="btn btn-success btn-guardar-comentario" 
                            data-dia-id="${dia.id}"
                        >
                            Guardar Comentario
                        </button>
                        <span class="mensaje-guardado text-success ms-2" style="display: none;">
                            ✓ Comentario guardado
                        </span>
                    </div>
                </div>
            </div>
        </div>
    `;

    // Agregar event listener para el botón de guardar
    const botonGuardar = contenedor.querySelector('.btn-guardar-comentario');
    botonGuardar.addEventListener('click', function() {
        const textarea = this.parentElement.previousElementSibling;
        const mensajeGuardado = this.nextElementSibling;
        guardarComentario(dia.id, textarea.value, mensajeGuardado, true);
    });
}

function configurarEventListeners(contenedor, planId) {
    // Event listeners para botones de guardar comentario
    const botonesGuardar = contenedor.querySelectorAll('.btn-guardar-comentario');
    botonesGuardar.forEach(boton => {
        boton.addEventListener('click', function() {
            const diaId = this.dataset.diaId;
            const textarea = this.parentElement.previousElementSibling;
            const mensajeGuardado = this.nextElementSibling;
            guardarComentario(diaId, textarea.value, mensajeGuardado);
        });
    });
 
    // Event listener para botón de observación
    const botonObservacion = contenedor.querySelector('.btn-generar-observacion');
    if (botonObservacion) {
        botonObservacion.addEventListener('click', function() {
            generarObservacion(planId);
        });
    }
}

function mostrarObservacion(observacion) {
    const contenedorObservacion = document.createElement('div');
    contenedorObservacion.className = 'contenedor-observacion mt-4 p-4 border rounded bg-light';
    
    // Limpiar y formatear el texto de la observación
    const observacionFormateada = observacion
        .split('\n')
        .map(parrafo => {
            // Eliminar asteriscos
            parrafo = parrafo.replace(/\*{2}/g, '');
            
            if (parrafo.match(/^\d+\./)) {
                return `<div class="observacion-item border-start border-primary ps-3 mb-3">${parrafo}</div>`;
            }
            return `<p>${parrafo}</p>`;
        })
        .join('');

    contenedorObservacion.innerHTML = `
        <h4 class="mb-4 border-bottom border-primary pb-2">Observación General</h4>
        <div class="observacion-contenido">
            ${observacionFormateada}
        </div>
    `;
    
    const observacionExistente = document.querySelector('.contenedor-observacion');
    if (observacionExistente) {
        observacionExistente.remove();
    }
    
    document.getElementById('detallesPlan').appendChild(contenedorObservacion);
}

function guardarComentario(diaId, comentario, mensajeElement, actualizarSelector = false) {
    fetch(`/planificacion/agregar_comentario/${diaId}/`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCookie('csrftoken')
        },
        body: JSON.stringify({ comentario })
    })
    .then(response => {
        if (!response.ok) throw new Error('Error al guardar el comentario');
        return response.json();
    })
    .then(data => {
        mensajeElement.style.display = 'inline-block';
        setTimeout(() => {
            mensajeElement.style.display = 'none';
        }, 3000);

        if (actualizarSelector) {
            const option = document.querySelector(`#selectDia option[value="${diaId}"]`);
            if (option && comentario.trim()) {
                option.dataset.comentado = 'true';
                if (!option.textContent.includes('✓')) {
                    option.textContent += ' ✓';
                }
            } else if (option && !comentario.trim()) {
                option.dataset.comentado = 'false';
                option.textContent = option.textContent.replace(' ✓', '');
            }
            actualizarEstadoObservacion(document.getElementById('selectDia'));
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error al guardar el comentario');
    });
}

function actualizarEstadoObservacion(selector, planId) {
    const options = Array.from(selector.options).slice(1); // Excluir la opción "Seleccione un día"
    const todosComentados = options.every(option => option.dataset.comentado === 'true');
    const observacionContainer = document.getElementById('observacionContainer');
    
    if (todosComentados) {
        if (!document.querySelector('.btn-generar-observacion')) {
            const botonObservacion = document.createElement('button');
            botonObservacion.className = 'btn-generar-observacion btn btn-primary';
            botonObservacion.textContent = 'Generar Observación';
            botonObservacion.onclick = () => generarObservacion(planId);
            observacionContainer.appendChild(botonObservacion);
        }
    } else {
        const botonExistente = document.querySelector('.btn-generar-observacion');
        if (botonExistente) {
            botonExistente.remove();
        }
    }
}

function generarObservacion(planId) {
    // Crear y mostrar el loader
    const detallesPlan = document.getElementById('detallesPlan');
    const loaderHTML = `
        <div class="temp-loader text-center p-4">
            <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
            <p class="text-gray-600">Generando observación...</p>
        </div>
    `;
    
    // Insertar el loader después del contenedor de observaciones
    const observacionContainer = document.getElementById('observacionContainer');
    observacionContainer.insertAdjacentHTML('afterend', loaderHTML);

    fetch(`/planificacion/generar_observacion/${planId}/`, {
        method: 'POST',
        headers: {
            'X-CSRFToken': getCookie('csrftoken')
        }
    })
    .then(response => response.json())
    .then(data => {
        // Remover el loader
        const loader = document.querySelector('.temp-loader');
        if (loader) {
            loader.remove();
        }

        if (data.observacion) {
            const contenedorObservacion = document.createElement('div');
            contenedorObservacion.className = 'contenedor-observacion mt-4 p-4 border rounded bg-light';
            
            // Formatear el texto de la observación
            const observacionFormateada = data.observacion
                .split('\n')
                .map(parrafo => {
                    // Manejar elementos numerados
                    if (parrafo.match(/^\d+\./)) {
                        return `<p class="observacion-item">${parrafo}</p>`;
                    }
                    // Manejar texto en negrita
                    parrafo = parrafo.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
                    return `<p>${parrafo}</p>`;
                })
                .join('');

            contenedorObservacion.innerHTML = `
                <h4 class="mb-4">Observación General</h4>
                <div class="observacion-contenido">
                    ${observacionFormateada}
                </div>
            `;
            
            // Buscar si ya existe una observación y reemplazarla
            const observacionExistente = document.querySelector('.contenedor-observacion');
            if (observacionExistente) {
                observacionExistente.remove();
            }
            
            document.getElementById('detallesPlan').appendChild(contenedorObservacion);
        } else {
            alert('Error al generar la observación');
        }
    })
    .catch(error => {
        // Remover el loader en caso de error
        const loader = document.querySelector('.temp-loader');
        if (loader) {
            loader.remove();
        }
        
        console.error('Error:', error);
        alert('Error al generar la observación');
    });
}