// static/js/file_management.js

let currentFolder = '';

function initializeFileManager() {
    console.log('Iniciando Administrador de Archivos...');
    loadFiles();
    setupEventListeners();
}

function setupEventListeners() {
    console.log('Setting up event listeners...');
    
    // Botones principales
    const createFolderBtn = document.getElementById('createFolderBtn');
    const uploadFileBtn = document.getElementById('uploadFileBtn');
    const backButton = document.getElementById('backButton');
    
    if (createFolderBtn) {
        createFolderBtn.addEventListener('click', () => showModal('createFolderModal'));
    }
    
    if (uploadFileBtn) {
        uploadFileBtn.addEventListener('click', () => showModal('uploadFileModal'));
    }
    
    if (backButton) {
        backButton.addEventListener('click', navigateUp);
    }
    
    // Formularios
    const createFolderForm = document.getElementById('createFolderForm');
    const uploadFileForm = document.getElementById('uploadFileForm');
    
    if (createFolderForm) {
        createFolderForm.addEventListener('submit', handleCreateFolder);
    }
    
    if (uploadFileForm) {
        uploadFileForm.addEventListener('submit', handleFileUpload);
    }
    
    // Cerrar modales
    const closeButtons = document.querySelectorAll('.close-modal');
    closeButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            const modalId = e.target.closest('.modal').id;
            hideModal(modalId);
        });
    });
}

function loadFiles() {
    console.log('Cargando archivos para la carpeta:', currentFolder);
    const url = currentFolder 
        ? `/admin_panel/files/list/${currentFolder}/`
        : '/admin_panel/files/list/';
        
    fetch(url)
        .then(response => {
            if (!response.ok) {
                throw new Error('La respuesta de la red no era correcta');
            }
            return response.json();
        })
        .then(data => {
            console.log('Archivos cargados:', data);
            displayFiles(data.items);
        })
        .catch(error => {
            console.error('Error al cargar los archivos:', error);
            alert('Error al cargar los archivos. Por favor, inténtelo de nuevo.');
        });
}

function displayFiles(items) {
    const fileList = document.getElementById('fileList');
    if (!fileList) {
        console.error('No se ha encontrado el contenedor de la lista de archivos');
        return;
    }
    
    fileList.innerHTML = '';
    
    // Mostrar la ruta actual
    const pathDisplay = document.createElement('div');
    pathDisplay.className = 'current-path';
    pathDisplay.textContent = currentFolder || 'Root';
    fileList.appendChild(pathDisplay);
    
    // Crear el contenedor de la cuadrícula
    const gridContainer = document.createElement('div');
    gridContainer.className = 'files-grid';
    
    items.forEach(item => {
        const itemElement = createItemElement(item);
        gridContainer.appendChild(itemElement);
    });
    
    fileList.appendChild(gridContainer);
}

function createItemElement(item) {
    const div = document.createElement('div');
    div.className = `file-item ${item.type}`;
    div.dataset.type = item.type;
    div.dataset.path = item.path;
    
    // Icono
    const icon = document.createElement('i');
    icon.className = item.type === 'folder' 
        ? 'fas fa-folder fa-2x'
        : 'fas fa-file-pdf fa-2x';
    
    // Nombre del archivo/carpeta
    const name = document.createElement('div');
    name.className = 'item-name';
    name.textContent = item.name;
    
    // Contenedor de acciones
    const actions = document.createElement('div');
    actions.className = 'file-actions';
    
    // Agregar acciones según el tipo
    if (item.type === 'folder') {
        div.addEventListener('click', (e) => {
            if (!e.target.closest('.file-actions')) {
                navigateToFolder(item.path);
            }
        });
    }
    
    if (item.type === 'file') {
        const downloadBtn = document.createElement('button');
        downloadBtn.className = 'btn btn-sm btn-info';
        downloadBtn.innerHTML = '<i class="fas fa-download"></i>';
        downloadBtn.title = 'Descargar';
        downloadBtn.onclick = (e) => {
            e.stopPropagation();
            downloadFile(item.path);
        };
        actions.appendChild(downloadBtn);
    }
    
    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'btn btn-sm btn-danger';
    deleteBtn.innerHTML = '<i class="fas fa-trash"></i>';
    deleteBtn.title = 'Borrar';
    deleteBtn.onclick = (e) => {
        e.stopPropagation();
        deleteItem(item.path, item.type);
    };
    actions.appendChild(deleteBtn);
    
    div.appendChild(icon);
    div.appendChild(name);
    div.appendChild(actions);
    
    return div;
}

function navigateToFolder(path) {
    currentFolder = path;
    loadFiles();
}

function navigateUp() {
    if (currentFolder) {
        const parts = currentFolder.split('/');
        parts.pop();
        currentFolder = parts.join('/');
        loadFiles();
    }
}

function handleCreateFolder(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    formData.append('parent', currentFolder);
    
    fetch('/admin_panel/files/create-folder/', {
        method: 'POST',
        body: formData,
        headers: {
            'X-CSRFToken': getCookie('csrftoken')
        }
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                hideModal('createFolderModal');
                event.target.reset();
                loadFiles();
            } else {
                alert('Error al crear carpeta: ' + (data.error || 'Error desconocido'));
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error al crear la carpeta. Por favor, inténtelo de nuevo.');
        });
}

function handleFileUpload(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    formData.append('folder', currentFolder);
    
    fetch('/admin_panel/files/upload/', {
        method: 'POST',
        body: formData,
        headers: {
            'X-CSRFToken': getCookie('csrftoken')
        }
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                hideModal('uploadFileModal');
                event.target.reset();
                loadFiles();
            } else {
                alert('Error al cargar el archivo: ' + (data.error || 'Error desconocido'));
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error al cargar el archivo. Por favor, inténtelo de nuevo.');
        });
}

function downloadFile(path) {
    window.location.href = `/admin_panel/files/download/${path}`;
}

function deleteItem(path, type) {
    if (confirm(`Seguro que quieres borrar esto ${type}?`)) {
        // Asegurarse de que la ruta termina en barra diagonal
        const safePath = path.endsWith('/') ? path : path + '/';
        
        fetch(`/admin_panel/files/delete/${safePath}`, {
            method: 'POST',
            headers: {
                'X-CSRFToken': getCookie('csrftoken')
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('La respuesta de la red no era correcta');
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                loadFiles();
            } else {
                alert('Error al borrar un elemento: ' + (data.error || 'Error desconocido'));
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error al borrar un elemento. Por favor, inténtelo de nuevo.');
        });
    }
}
// Función auxiliar para obtener el token CSRF
function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}
// Show/Hide Modal functions
function showModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'block';
    }
}

function hideModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'none';
    }
}